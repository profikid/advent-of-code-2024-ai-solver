import solution from './solution.js';

describe('Day 2 Part 2: Rock Paper Scissors Strategy', () => {
  it('should calculate total score based on needed outcomes', () => {
    const input = `A Y
B X
C Z`;
    expect(solution(input)).toBe(12);
  });

  it('should handle single round correctly', () => {
    // A (Rock) Y (Draw) -> should choose Rock (1) + Draw (3) = 4
    expect(solution('A Y')).toBe(4);
    // B (Paper) X (Lose) -> should choose Rock (1) + Lose (0) = 1
    expect(solution('B X')).toBe(1);
    // C (Scissors) Z (Win) -> should choose Rock (1) + Win (6) = 7
    expect(solution('C Z')).toBe(7);
  });
});