export default function solution(input) {
  const rounds = input.trim().split('\n');
  
  // Score for shapes
  const SHAPE_SCORES = {
    'ROCK': 1,
    'PAPER': 2,
    'SCISSORS': 3
  };

  // Outcome scores
  const OUTCOME_SCORES = {
    'LOSE': 0,
    'DRAW': 3,
    'WIN': 6
  };

  // Map opponent moves
  const OPPONENT_MOVES = {
    'A': 'ROCK',
    'B': 'PAPER',
    'C': 'SCISSORS'
  };

  // Map needed outcomes
  const NEEDED_OUTCOMES = {
    'X': 'LOSE',
    'Y': 'DRAW',
    'Z': 'WIN'
  };

  // Function to determine what shape to choose based on opponent's move and needed outcome
  function getShapeToPlay(opponentShape, neededOutcome) {
    if (neededOutcome === 'DRAW') {
      return opponentShape;
    }
    
    if (neededOutcome === 'WIN') {
      if (opponentShape === 'ROCK') return 'PAPER';
      if (opponentShape === 'PAPER') return 'SCISSORS';
      if (opponentShape === 'SCISSORS') return 'ROCK';
    }
    
    if (neededOutcome === 'LOSE') {
      if (opponentShape === 'ROCK') return 'SCISSORS';
      if (opponentShape === 'PAPER') return 'ROCK';
      if (opponentShape === 'SCISSORS') return 'PAPER';
    }
  }

  let totalScore = 0;

  for (const round of rounds) {
    const [opponent, outcome] = round.split(' ');
    
    const opponentShape = OPPONENT_MOVES[opponent];
    const neededOutcome = NEEDED_OUTCOMES[outcome];
    const myShape = getShapeToPlay(opponentShape, neededOutcome);
    
    // Calculate score for this round
    const shapeScore = SHAPE_SCORES[myShape];
    const outcomeScore = OUTCOME_SCORES[neededOutcome];
    
    totalScore += shapeScore + outcomeScore;
  }

  return totalScore;
}