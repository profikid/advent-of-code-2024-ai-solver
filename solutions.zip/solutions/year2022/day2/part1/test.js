import solution from './solution.js';

describe('Day 2 Part 1 - Rock Paper Scissors', () => {
    test('should calculate total score according to strategy guide', () => {
        const input = `A Y
B X
C Z`;
        
        // Round 1: Paper (Y=2) + Win (6) = 8
        // Round 2: Rock (X=1) + Loss (0) = 1
        // Round 3: Scissors (Z=3) + Draw (3) = 6
        // Total: 8 + 1 + 6 = 15
        expect(solution(input)).toBe(15);
    });

    test('should handle invalid input', () => {
        expect(solution('')).toBe(0);
    });

    test('should handle single round', () => {
        expect(solution('A Y')).toBe(8);
    });
});