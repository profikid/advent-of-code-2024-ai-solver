export default function solution(input) {
    if (!input) return 0;

    const rounds = input.trim().split('\n');
    
    // Score mapping for shape selection
    const shapeScores = {
        'X': 1, // Rock
        'Y': 2, // Paper
        'Z': 3  // Scissors
    };

    // Outcome mapping: [opponent, you] => score
    const outcomeScores = {
        'A X': 3, // Rock vs Rock = Draw
        'A Y': 6, // Rock vs Paper = Win
        'A Z': 0, // Rock vs Scissors = Loss
        'B X': 0, // Paper vs Rock = Loss
        'B Y': 3, // Paper vs Paper = Draw
        'B Z': 6, // Paper vs Scissors = Win
        'C X': 6, // Scissors vs Rock = Win
        'C Y': 0, // Scissors vs Paper = Loss
        'C Z': 3  // Scissors vs Scissors = Draw
    };

    return rounds.reduce((totalScore, round) => {
        const [_, yourShape] = round.split(' ');
        const shapeScore = shapeScores[yourShape];
        const outcomeScore = outcomeScores[round];
        
        return totalScore + shapeScore + outcomeScore;
    }, 0);
}