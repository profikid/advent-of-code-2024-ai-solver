export default function solution(input) {
    // Split input by double newline to separate elves
    const elves = input.trim().split('\n\n');
    
    // For each elf, sum their calories
    const totalCalories = elves.map(elf => {
        // Split elf's inventory by newline and convert to numbers
        const calories = elf.split('\n')
            .map(cal => parseInt(cal.trim()))
            .filter(cal => !isNaN(cal)); // Handle any invalid numbers
        
        // Sum the calories
        return calories.reduce((sum, current) => sum + current, 0);
    });
    
    // Find the maximum calories
    return Math.max(...totalCalories);
}