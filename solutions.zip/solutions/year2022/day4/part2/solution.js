export default function solution(input) {
    // Split input into lines and filter out empty lines
    const pairs = input.trim().split('\n').filter(line => line);
    
    // Count pairs where one range fully contains the other
    return pairs.reduce((count, pair) => {
        // Split each pair into two ranges
        const [range1, range2] = pair.split(',');
        
        // Parse the ranges into start and end numbers
        const [start1, end1] = range1.split('-').map(Number);
        const [start2, end2] = range2.split('-').map(Number);
        
        // Check if one range fully contains the other
        if ((start1 <= start2 && end1 >= end2) || 
            (start2 <= start1 && end2 >= end1)) {
            return count + 1;
        }
        
        return count;
    }, 0);
}