import solution from './solution.js';

describe('day 4 part 1 - Camp Cleanup', () => {
  test('should count pairs where one range fully contains the other', () => {
    const input = `2-4,6-8
2-3,4-5
5-7,7-9
2-8,3-7
6-6,4-6
2-6,4-8`;
    expect(solution(input)).toBe(2);
  });

  test('handles single pair', () => {
    const input = '2-8,3-7';
    expect(solution(input)).toBe(1);
  });

  test('handles no containment', () => {
    const input = '2-4,6-8\n2-3,4-5';
    expect(solution(input)).toBe(0);
  });

  test('handles empty input', () => {
    expect(solution('')).toBe(0);
  });
});