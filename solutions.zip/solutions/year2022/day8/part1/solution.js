export default function solution(input) {
    // Parse input into 2D array of numbers
    const grid = input.split('\n').map(row => row.split('').map(Number));
    
    if (grid.length === 0) return 0;
    
    const height = grid.length;
    const width = grid[0].length;
    
    // Set to track visible trees (using string coordinates as keys)
    const visibleTrees = new Set();
    
    // Check visibility from left and right
    for (let row = 0; row < height; row++) {
        // Left to right
        let maxHeight = -1;
        for (let col = 0; col < width; col++) {
            if (grid[row][col] > maxHeight) {
                visibleTrees.add(`${row},${col}`);
                maxHeight = grid[row][col];
            }
        }
        
        // Right to left
        maxHeight = -1;
        for (let col = width - 1; col >= 0; col--) {
            if (grid[row][col] > maxHeight) {
                visibleTrees.add(`${row},${col}`);
                maxHeight = grid[row][col];
            }
        }
    }
    
    // Check visibility from top and bottom
    for (let col = 0; col < width; col++) {
        // Top to bottom
        let maxHeight = -1;
        for (let row = 0; row < height; row++) {
            if (grid[row][col] > maxHeight) {
                visibleTrees.add(`${row},${col}`);
                maxHeight = grid[row][col];
            }
        }
        
        // Bottom to top
        maxHeight = -1;
        for (let row = height - 1; row >= 0; row--) {
            if (grid[row][col] > maxHeight) {
                visibleTrees.add(`${row},${col}`);
                maxHeight = grid[row][col];
            }
        }
    }
    
    return visibleTrees.size;
}