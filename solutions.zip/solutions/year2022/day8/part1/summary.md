I've created a complete solution for Day 8, Part 1. Let me explain the implementation:

1. First, I created tests that cover:
   - The main example from the puzzle
   - Edge cases like single row/column
   - Empty input handling

2. The solution works by:
   - Converting the input into a 2D array of numbers
   - Using a Set to keep track of visible trees (to avoid counting duplicates)
   - Scanning each row from left and right
   - Scanning each column from top and bottom
   - For each direction, keeping track of the maximum height seen so far
   - Adding trees to the Set when they are taller than all previous trees in that direction

3. Key features of the solution:
   - Handles edge cases (empty input, single row/column)
   - Efficient using a Set to avoid duplicate counting
   - Clear and maintainable code structure
   - Safe array access without out-of-bounds issues

4. The solve script:
   - Reads the input file
   - Trims any extra whitespace
   - Runs the solution
   - Writes the result to the output file

The solution successfully passed all the tests and ran against the actual input. Each tree is evaluated from all four directions (left, right, top, bottom) and is considered visible if it can be seen from at least one direction.

Would you like me to explain any specific part in more detail or proceed with Part 2 of the puzzle?