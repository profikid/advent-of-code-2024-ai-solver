I've created a solution for Day 5 Part 1. Let me explain the solution step by step:

1. First, I split the input into two sections:
   - Rules section (containing the page ordering rules)
   - Updates section (containing the lists of pages to be printed)

2. For the rules, I created a dependencies Map where:
   - The key is the page number that has dependencies
   - The value is a Set of page numbers that must come before the key

3. The main logic is in the `isValidOrder` function which:
   - Takes an array of page numbers (an update)
   - For each page in the update:
     - Checks if it has any dependencies
     - If it does, verifies that all required pages (that exist in the update) come before it
     - Returns false if any violation is found
     - Returns true if all dependencies are satisfied

4. Then for each valid update:
   - Find the middle page (using integer division)
   - Sum up all middle pages

5. The test verifies the example case where:
   - Three updates are valid: [75,47,61,53,29], [97,61,53,29,13], and [75,29,13]
   - Their middle pages are 61, 53, and 29 respectively
   - The sum is 143

The solution handles all edge cases:
- Missing pages in updates (by only checking rules for pages that exist in the update)
- Multiple dependencies for a single page
- Various update lengths
- Invalid orders that would break rules

The solution has passed both the test case and processed the actual input. Let me know if you need any clarification or if there's a Part 2 to solve!