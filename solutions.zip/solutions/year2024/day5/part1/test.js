import solution from './solution.js';

describe('Day 5: Print Queue - Part 1', () => {
    const example = `47|53
97|13
97|61
97|47
75|29
61|13
75|53
29|13
97|29
53|29
61|53
97|53
61|29
47|13
75|47
97|75
47|61
75|61
47|29
75|13
53|13

75,47,61,53,29
97,61,53,29,13
75,29,13
75,97,47,61,53
61,13,29
97,13,75,29,47`;

    test('should return correct sum of middle numbers for valid updates', () => {
        expect(solution(example)).toBe(143);
    });

    test('should validate individual updates correctly', () => {
        // Valid update
        const valid1 = `47|53\n53|29\n47|29\n\n47,53,29`;
        expect(solution(valid1)).toBe(53);

        // Invalid update (breaks rule)
        const invalid1 = `47|53\n53|29\n47|29\n\n53,47,29`;
        expect(solution(invalid1)).toBe(0);
    });

    test('should handle empty updates section', () => {
        const emptyUpdates = `47|53\n53|29\n\n`;
        expect(solution(emptyUpdates)).toBe(0);
    });
});