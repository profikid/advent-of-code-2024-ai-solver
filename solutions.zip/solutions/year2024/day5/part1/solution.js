export default function solution(input) {
    // Split input into rules and updates sections
    const [rulesSection, updatesSection] = input.trim().split('\n\n');
    
    if (!updatesSection || !rulesSection) return 0;

    // Parse rules into a map
    const rules = new Map();
    rulesSection.split('\n').forEach(rule => {
        const [before, after] = rule.split('|').map(Number);
        if (!rules.has(before)) rules.set(before, new Set());
        rules.get(before).add(after);
    });

    // Process each update
    const updates = updatesSection.split('\n').map(update => 
        update.split(',').map(Number)
    );

    const validUpdatesMiddles = [];

    // Check each update
    for (const update of updates) {
        if (isValidUpdate(update, rules)) {
            // Get middle number
            const middleIndex = Math.floor(update.length / 2);
            validUpdatesMiddles.push(update[middleIndex]);
        }
    }

    // Sum up middle numbers
    return validUpdatesMiddles.reduce((sum, num) => sum + num, 0);
}

function isValidUpdate(update, rules) {
    // For each pair of numbers in the update
    for (let i = 0; i < update.length; i++) {
        for (let j = i + 1; j < update.length; j++) {
            const first = update[i];
            const second = update[j];

            // If there's a rule saying second should come before first
            if (rules.has(second) && rules.get(second).has(first)) {
                return false;
            }

            // Check transitive relationships
            if (!isValidTransitiveOrder(first, second, rules, new Set(), update)) {
                return false;
            }
        }
    }
    return true;
}

function isValidTransitiveOrder(first, second, rules, visited, update) {
    // If there's a direct rule violation
    if (rules.has(second) && rules.get(second).has(first)) {
        return false;
    }

    // Check for transitive relationships
    if (rules.has(first)) {
        const mustBeAfter = rules.get(first);
        if (mustBeAfter.has(second)) {
            return true;
        }

        // Avoid cyclic dependencies
        if (visited.has(first)) {
            return true;
        }
        visited.add(first);

        // Only check transitive relationships for numbers that are in the update
        for (const middle of mustBeAfter) {
            if (update.includes(middle)) {
                if (!isValidTransitiveOrder(middle, second, rules, visited, update)) {
                    return false;
                }
            }
        }
    }

    return true;
}