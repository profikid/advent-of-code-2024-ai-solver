import fs from 'fs';
import solution from './solution.js';

const input = fs.readFileSync('input.txt', 'utf-8');
const { part1, part2 } = solution(input);

console.log('Part 1:', part1);
console.log('Part 2:', part2);

fs.writeFileSync('output.txt', `${part1}\n${part2}`);