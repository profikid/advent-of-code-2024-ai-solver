export default function solution(input) {
  // Parse input
  const [rulesSection, updatesSection] = input.trim().split('\n\n');
  
  // Parse rules into a map of dependencies
  const rules = new Map();
  rulesSection.split('\n').forEach(rule => {
    const [before, after] = rule.split('|').map(Number);
    if (!rules.has(before)) rules.set(before, new Set());
    if (!rules.has(after)) rules.set(after, new Set());
    rules.get(after).add(before);
  });

  // Parse updates
  const updates = updatesSection.split('\n').map(line => line.split(',').map(Number));

  // Helper function to check if an order is valid
  function isValidOrder(pages) {
    for (let i = 0; i < pages.length; i++) {
      const current = pages[i];
      // For each page after the current one
      for (let j = i + 1; j < pages.length; j++) {
        const later = pages[j];
        // If there's a rule saying later should come before current, order is invalid
        if (rules.has(current) && rules.get(current).has(later)) {
          return false;
        }
      }
    }
    return true;
  }

  // Helper function to get middle number
  function getMiddleNumber(arr) {
    return arr[Math.floor(arr.length / 2)];
  }

  // Helper function to sort pages according to rules
  function sortPages(pages) {
    return pages.slice().sort((a, b) => {
      // If b should come before a, return 1
      if (rules.has(a) && rules.get(a).has(b)) return 1;
      // If a should come before b, return -1
      if (rules.has(b) && rules.get(b).has(a)) return -1;
      // If no direct relationship, maintain relative order
      return a - b;
    });
  }

  // Part 1: Find sum of middle numbers of valid sequences
  const validUpdates = updates.filter(isValidOrder);
  const part1 = validUpdates.reduce((sum, update) => sum + getMiddleNumber(update), 0);

  // Part 2: Find sum of middle numbers of fixed invalid sequences
  const invalidUpdates = updates.filter(update => !isValidOrder(update));
  const part2 = invalidUpdates.reduce((sum, update) => {
    const sortedUpdate = sortPages(update);
    return sum + getMiddleNumber(sortedUpdate);
  }, 0);

  return { part1, part2 };
}