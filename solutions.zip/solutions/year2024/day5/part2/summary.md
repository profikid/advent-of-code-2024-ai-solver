I've created a solution for both parts of the puzzle. Let me explain the approach:

1. First, we parse the input into two sections:
   - Rules section: Contains the page ordering rules (X|Y)
   - Updates section: Contains the lists of pages to be printed

2. For Part 1:
   - We create a Map to store the dependencies where each page number maps to a Set of pages that must come before it
   - We have a helper function `isValidOrder` that checks if a sequence respects all rules
   - For each update, we check if it's valid and collect the middle numbers of valid sequences
   - Sum up all middle numbers of valid sequences

3. For Part 2:
   - We identify the invalid sequences using the same `isValidOrder` function
   - Created a `sortPages` function that sorts pages according to the rules
   - For each invalid sequence:
     - Sort it according to the rules
     - Get the middle number
   - Sum up all middle numbers of corrected sequences

The solution handles both parts and includes careful error checking:
- Ensures proper input parsing
- Handles missing dependencies
- Takes care of edge cases with the sorting algorithm
- Uses proper ES6 module syntax
- Includes comprehensive tests for both parts

The test cases verify both parts using the example input from the puzzle description. The solution has passed both test cases and successfully processes the actual input data.