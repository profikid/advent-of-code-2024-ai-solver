export default function solution(input) {
    if (!input || !input.trim()) {
        return 0;
    }

    // Parse the grid
    const grid = input.trim().split('\n').map(line => line.split(''));
    const height = grid.length;
    const width = grid[0].length;

    // Find starting position and direction of guard
    let startPos = { x: -1, y: -1, direction: '' };
    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            if (grid[y][x] === '^') {
                startPos = { x, y, direction: 'up' };
            }
        }
    }

    if (startPos.x === -1) return 0; // No guard found

    // Set to track visited positions
    const visited = new Set();
    
    // Current position
    let current = { ...startPos };
    visited.add(`${current.x},${current.y}`);

    // Direction mapping for turning right
    const directions = {
        'up': 'right',
        'right': 'down',
        'down': 'left',
        'left': 'up'
    };

    // Movement deltas for each direction
    const moves = {
        'up': { dx: 0, dy: -1 },
        'right': { dx: 1, dy: 0 },
        'down': { dx: 0, dy: 1 },
        'left': { dx: -1, dy: 0 }
    };

    while (true) {
        // Check if we're still in bounds
        if (current.x < 0 || current.x >= width || current.y < 0 || current.y >= height) {
            break;
        }

        // Get next position based on current direction
        const move = moves[current.direction];
        const nextX = current.x + move.dx;
        const nextY = current.y + move.dy;

        // Check if there's an obstacle ahead or we'll go out of bounds
        if (nextX < 0 || nextX >= width || nextY < 0 || nextY >= height || grid[nextY][nextX] === '#') {
            // Turn right
            current.direction = directions[current.direction];
        } else {
            // Move forward
            current.x = nextX;
            current.y = nextY;
            visited.add(`${current.x},${current.y}`);
        }
    }

    return visited.size;
}