import solution from './solution.js';

describe('Day 6: Guard Gallivant - Part 1', () => {
    const example = `....#.....
.........#
..........
..#.......
.......#..
..........
.#..^.....
........#.
#.........
......#...`;

    test('should count distinct positions visited by guard before leaving map', () => {
        expect(solution(example)).toBe(41);
    });

    test('should handle empty input', () => {
        expect(solution('')).toBe(0);
    });

    test('should handle input with no guard', () => {
        expect(solution('.....\n.....').trim()).toBe(0);
    });
});