function findAllXMAS(grid) {
  const rows = grid.length;
  const cols = grid[0].length;
  let count = 0;

  // Check all possible directions
  const directions = [
    [0, 1],   // right
    [1, 0],   // down
    [1, 1],   // diagonal right down
    [1, -1],  // diagonal left down
    [0, -1],  // left
    [-1, 0],  // up
    [-1, 1],  // diagonal right up
    [-1, -1], // diagonal left up
  ];

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      for (const [dy, dx] of directions) {
        let found = true;
        const word = 'XMAS';
        
        for (let i = 0; i < word.length; i++) {
          const newRow = row + dy * i;
          const newCol = col + dx * i;
          
          if (newRow < 0 || newRow >= rows || 
              newCol < 0 || newCol >= cols || 
              grid[newRow][newCol] !== word[i]) {
            found = false;
            break;
          }
        }
        
        if (found) count++;
      }
    }
  }
  
  return count;
}

function findXMASPatterns(grid) {
  const rows = grid.length;
  const cols = grid[0].length;
  let count = 0;

  for (let row = 1; row < rows - 1; row++) {
    for (let col = 1; col < cols - 1; col++) {
      if (grid[row][col] === 'A') {
        // Check all possible combinations of MAS patterns forming an X
        const patterns = [
          // Upper left to lower right + Upper right to lower left
          [[row-1, col-1], [row+1, col+1], [row-1, col+1], [row+1, col-1]],
        ];

        for (const [[r1, c1], [r2, c2], [r3, c3], [r4, c4]] of patterns) {
          if (r1 >= 0 && r2 < rows && c1 >= 0 && c2 < cols &&
              r3 >= 0 && r4 < rows && c3 < cols && c4 >= 0) {
            
            // Check all possible combinations of MAS (forward and backward)
            const combinations = [
              // Both forward
              [['M', 'A', 'S'], ['M', 'A', 'S']],
              // Both backward
              [['S', 'A', 'M'], ['S', 'A', 'M']],
              // First forward, second backward
              [['M', 'A', 'S'], ['S', 'A', 'M']],
              // First backward, second forward
              [['S', 'A', 'M'], ['M', 'A', 'S']]
            ];

            for (const [pattern1, pattern2] of combinations) {
              if (
                // First diagonal
                grid[r1][c1] === pattern1[0] &&
                grid[row][col] === pattern1[1] &&
                grid[r2][c2] === pattern1[2] &&
                // Second diagonal
                grid[r3][c3] === pattern2[0] &&
                grid[row][col] === pattern2[1] &&
                grid[r4][c4] === pattern2[2]
              ) {
                count++;
              }
            }
          }
        }
      }
    }
  }

  return count;
}

export default function solution(input) {
  const grid = input.split('\n').map(line => line.split(''));
  
  return {
    part1: findAllXMAS(grid),
    part2: findXMASPatterns(grid)
  };
}