import solution from './solution.js';

describe('Day 4: Ceres Search', () => {
  const example = `MMMSXXMASM
MSAMXMSMSA
AMXSXMAAMM
MSAMASMSMX
XMASAMXAMM
XXAMMXXAMA
SMSMSASXSS
SAXAMASAAA
MAMMMXMMMM
MXMXAXMASX`;

  describe('Part 1', () => {
    it('should find all XMAS occurrences in all directions', () => {
      expect(solution(example).part1).toBe(18);
    });
  });

  describe('Part 2', () => {
    it('should find all X-MAS patterns', () => {
      expect(solution(example).part2).toBe(9);
    });
  });
});