import solution from './solution.js';

describe('Day 1: Historian Hysteria', () => {
  const example = `3   4
4   3
2   5
1   3
3   9
3   3`;

  test('Part 1: Calculate total distance between lists', () => {
    expect(solution(example).part1).toBe(11);
  });

  test('Part 2: Calculate similarity score', () => {
    expect(solution(example).part2).toBe(31);
  });
});