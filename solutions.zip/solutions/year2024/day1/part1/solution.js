export default function solution(input) {
  // Parse input into two arrays of numbers
  const lines = input.trim().split('\n');
  const [leftList, rightList] = lines.reduce(
    ([left, right], line) => {
      const [l, r] = line.trim().split(/\s+/).map(Number);
      return [
        [...left, l],
        [...right, r],
      ];
    },
    [[], []]
  );

  // Part 1: Calculate total distance between sorted lists
  const part1 = () => {
    const sortedLeft = [...leftList].sort((a, b) => a - b);
    const sortedRight = [...rightList].sort((a, b) => a - b);
    
    return sortedLeft.reduce((sum, num, index) => {
      return sum + Math.abs(num - sortedRight[index]);
    }, 0);
  };

  // Part 2: Calculate similarity score
  const part2 = () => {
    // Count occurrences in right list
    const rightCounts = rightList.reduce((counts, num) => {
      counts[num] = (counts[num] || 0) + 1;
      return counts;
    }, {});

    // Calculate similarity score
    return leftList.reduce((score, num) => {
      return score + (num * (rightCounts[num] || 0));
    }, 0);
  };

  return {
    part1: part1(),
    part2: part2()
  };
}