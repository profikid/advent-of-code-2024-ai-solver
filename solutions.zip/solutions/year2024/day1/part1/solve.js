import fs from 'fs';
import solution from './solution.js';

const input = fs.readFileSync('input.txt', 'utf-8');
const result = solution(input);

// Write the results to output.txt
fs.writeFileSync('output.txt', `Part 1: ${result.part1}\nPart 2: ${result.part2}`);