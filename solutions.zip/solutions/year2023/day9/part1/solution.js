export default function solution(input) {
  // Split input into lines and convert each line to array of numbers
  const sequences = input.trim().split('\n').map(line => 
    line.trim().split(/\s+/).map(Number)
  );

  // Calculate next value for each sequence and sum them
  return sequences.reduce((sum, sequence) => {
    return sum + findNextValue(sequence);
  }, 0);
}

function findNextValue(sequence) {
  // If sequence is all zeros, return 0
  if (sequence.every(num => num === 0)) {
    return 0;
  }

  // Calculate differences between consecutive numbers
  const differences = [];
  for (let i = 1; i < sequence.length; i++) {
    differences.push(sequence[i] - sequence[i - 1]);
  }

  // Recursively find next value in difference sequence
  const nextDifference = findNextValue(differences);
  
  // Return last value plus the next difference
  return sequence[sequence.length - 1] + nextDifference;
}