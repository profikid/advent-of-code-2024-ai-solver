import solution from './solution.js';

describe('Day 9: Mirage Maintenance - Part 1', () => {
  it('should calculate next values in sequences and sum them', () => {
    const input = `0 3 6 9 12 15
1 3 6 10 15 21
10 13 16 21 30 45`;
    
    expect(solution(input)).toBe(114);
  });

  it('should handle single sequence', () => {
    const input = '0 3 6 9 12 15';
    expect(solution(input)).toBe(18);
  });

  it('should handle sequence with more differences', () => {
    const input = '10 13 16 21 30 45';
    expect(solution(input)).toBe(68);
  });
});