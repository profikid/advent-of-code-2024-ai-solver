export default function solution(input, part2 = false) {
  // Parse input into array of number arrays
  const sequences = input.split('\n').map(line => 
    line.trim().split(/\s+/).map(Number)
  );

  return sequences.reduce((sum, sequence) => {
    const differences = [sequence];
    
    // Calculate differences until all zeros
    while (!differences[differences.length - 1].every(n => n === 0)) {
      const lastSeq = differences[differences.length - 1];
      const newSeq = [];
      
      for (let i = 1; i < lastSeq.length; i++) {
        newSeq.push(lastSeq[i] - lastSeq[i - 1]);
      }
      
      differences.push(newSeq);
    }

    if (part2) {
      // Extrapolate backwards
      let firstValue = 0;
      for (let i = differences.length - 2; i >= 0; i--) {
        firstValue = differences[i][0] - firstValue;
      }
      return sum + firstValue;
    } else {
      // Extrapolate forwards
      let nextValue = 0;
      for (let i = differences.length - 2; i >= 0; i--) {
        const seq = differences[i];
        nextValue = seq[seq.length - 1] + nextValue;
      }
      return sum + nextValue;
    }
  }, 0);
}