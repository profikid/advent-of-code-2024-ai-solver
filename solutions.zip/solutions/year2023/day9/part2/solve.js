import fs from 'fs';
import solution from './solution.js';

const input = fs.readFileSync('input.txt', 'utf-8');

// Part 1
const result1 = solution(input);
// Part 2
const result2 = solution(input, true);

fs.writeFileSync('output.txt', `Part 1: ${result1}\nPart 2: ${result2}`);