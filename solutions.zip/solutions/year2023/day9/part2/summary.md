I've implemented a solution for both parts of Day 9. Let me explain the approach:

1. First, I created a test file that checks both parts using the example data provided in the puzzle. For part 1, it should return 114, and for part 2, it should return 2.

2. The solution works as follows:

For Part 1:
- Parse input into arrays of numbers
- For each sequence:
  1. Calculate differences between consecutive numbers until we get all zeros
  2. Store all sequences of differences in an array
  3. Starting from the bottom (all zeros), work our way up adding the last number of each sequence to find the next value
- Sum up all the extrapolated values

For Part 2:
- Uses the same difference calculation but:
  1. Instead of working with the last numbers, we work with the first numbers
  2. Instead of adding, we subtract the differences to extrapolate backwards
  3. Sum up all the extrapolated previous values

The solution takes an optional `part2` parameter to switch between the two modes of operation.

Key features of the implementation:
- Handles input parsing robustly with trim() and proper number conversion
- Uses reduce to accumulate the sum of extrapolated values
- Calculates differences until reaching all zeros
- Works with both positive and negative numbers
- Clean and modular code structure

The tests pass for both parts using the example data, and the solve script has been created to handle the actual input file.