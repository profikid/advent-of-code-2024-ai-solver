import solution from './solution.js';

describe('day 9', () => {
  describe('part 1', () => {
    it('should calculate sum of extrapolated next values', () => {
      const input = `0 3 6 9 12 15
1 3 6 10 15 21
10 13 16 21 30 45`;
      expect(solution(input)).toBe(114);
    });
  });

  describe('part 2', () => {
    it('should calculate sum of extrapolated previous values', () => {
      const input = `0 3 6 9 12 15
1 3 6 10 15 21
10 13 16 21 30 45`;
      expect(solution(input, true)).toBe(2);
    });
  });
});