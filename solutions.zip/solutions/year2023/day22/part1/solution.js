class Brick {
    constructor(x1, y1, z1, x2, y2, z2) {
        this.x1 = Math.min(x1, x2);
        this.y1 = Math.min(y1, y2);
        this.z1 = Math.min(z1, z2);
        this.x2 = Math.max(x1, x2);
        this.y2 = Math.max(y1, y2);
        this.z2 = Math.max(z1, z2);
        this.supporting = new Set();
        this.supportedBy = new Set();
    }

    overlapsXY(other) {
        return Math.max(this.x1, other.x1) <= Math.min(this.x2, other.x2) &&
               Math.max(this.y1, other.y1) <= Math.min(this.y2, other.y2);
    }
}

function parseInput(input) {
    return input.split('\n').map(line => {
        const [start, end] = line.split('~');
        const [x1, y1, z1] = start.split(',').map(Number);
        const [x2, y2, z2] = end.split(',').map(Number);
        return new Brick(x1, y1, z1, x2, y2, z2);
    });
}

function settleBricks(bricks) {
    // Sort bricks by z coordinate
    bricks.sort((a, b) => a.z1 - b.z1);

    for (let i = 0; i < bricks.length; i++) {
        const brick = bricks[i];
        let maxZ = 1; // Ground level

        // Find highest brick below current brick that overlaps in xy plane
        for (let j = 0; j < i; j++) {
            const lower = bricks[j];
            if (brick.overlapsXY(lower)) {
                maxZ = Math.max(maxZ, lower.z2 + 1);
            }
        }

        // Drop brick to new position
        const drop = brick.z1 - maxZ;
        brick.z1 -= drop;
        brick.z2 -= drop;

        // Update support relationships
        for (let j = 0; j < i; j++) {
            const lower = bricks[j];
            if (brick.overlapsXY(lower) && brick.z1 === lower.z2 + 1) {
                brick.supportedBy.add(j);
                lower.supporting.add(i);
            }
        }
    }

    return bricks;
}

export default function solution(input) {
    const bricks = parseInput(input);
    settleBricks(bricks);

    let safeToDisintegrate = 0;

    for (let i = 0; i < bricks.length; i++) {
        const brick = bricks[i];
        let canDisintegrate = true;

        // Check each brick that this one supports
        for (const supportedIdx of brick.supporting) {
            const supported = bricks[supportedIdx];
            // If any supported brick has only one support (this brick),
            // then this brick cannot be disintegrated
            if (supported.supportedBy.size === 1) {
                canDisintegrate = false;
                break;
            }
        }

        if (canDisintegrate) {
            safeToDisintegrate++;
        }
    }

    return safeToDisintegrate;
}