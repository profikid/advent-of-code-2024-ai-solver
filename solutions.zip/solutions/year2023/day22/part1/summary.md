I've created a solution for Day 22 Part 1. Let me explain the approach:

1. First, I created a Brick class to represent each brick with:
   - Coordinates (x1,y1,z1) to (x2,y2,z2)
   - Sets to track which bricks it supports and which bricks support it
   - A method to check if two bricks overlap in the XY plane

2. The main algorithm works in these steps:
   - Parse the input into Brick objects
   - Sort bricks by their lowest z-coordinate to process them from bottom to top
   - For each brick:
     - Find the highest point it can fall to by checking overlaps with bricks below
     - Drop the brick to that position
     - Update support relationships

3. To find bricks that can be safely disintegrated:
   - For each brick, check all bricks it supports
   - If any supported brick has only one support (the current brick), then the current brick cannot be disintegrated
   - Otherwise, the brick can be safely disintegrated

4. The test cases cover:
   - The main example from the puzzle
   - Simple cases with single cube bricks
   - Cases where bricks don't support anything

The solution takes care of edge cases by:
- Using Math.min/max to handle coordinates in any order
- Properly handling single-cube bricks
- Considering ground level (z=1) as the lowest possible position
- Checking for overlaps in the XY plane before establishing support relationships

The code has been tested and should work correctly with the puzzle input to find how many bricks can be safely disintegrated.