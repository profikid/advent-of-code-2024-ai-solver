import solution from './solution.js';

describe('day 22 part 1', () => {
    it('should count bricks that can be safely disintegrated', () => {
        const input = `1,0,1~1,2,1
0,0,2~2,0,2
0,2,3~2,2,3
0,0,4~0,2,4
2,0,5~2,2,5
0,1,6~2,1,6
1,1,8~1,1,9`;

        expect(solution(input)).toBe(5);
    });

    it('should handle single cube bricks', () => {
        const input = `1,1,1~1,1,1
1,1,2~1,1,2`;
        expect(solution(input)).toBe(1);
    });

    it('should handle bricks that dont support anything', () => {
        const input = `1,1,1~1,1,1
1,2,2~1,2,2`;
        expect(solution(input)).toBe(2);
    });
});