import solution from './solution.js';

describe('Day 22: Sand Slabs (Part 2)', () => {
  const example = `1,0,1~1,2,1
0,0,2~2,0,2
0,2,3~2,2,3
0,0,4~0,2,4
2,0,5~2,2,5
0,1,6~2,1,6
1,1,8~1,1,9`;

  test('should calculate total falling bricks from chain reactions', () => {
    expect(solution(example)).toBe(7);
  });

  test('individual cases from example', () => {
    const result = solution(example, true);
    // Brick A causes 6 other bricks to fall
    expect(result[0]).toBe(6);
    // Brick F causes 1 other brick (G) to fall
    expect(result[5]).toBe(1);
  });
});