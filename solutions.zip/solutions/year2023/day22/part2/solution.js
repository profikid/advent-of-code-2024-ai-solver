class Brick {
  constructor(line) {
    const [start, end] = line.split('~').map(coords => coords.split(',').map(Number));
    this.x1 = Math.min(start[0], end[0]);
    this.x2 = Math.max(start[0], end[0]);
    this.y1 = Math.min(start[1], end[1]);
    this.y2 = Math.max(start[1], end[1]);
    this.z1 = Math.min(start[2], end[2]);
    this.z2 = Math.max(start[2], end[2]);
  }

  getAllPositions() {
    const positions = [];
    for (let x = this.x1; x <= this.x2; x++) {
      for (let y = this.y1; y <= this.y2; y++) {
        for (let z = this.z1; z <= this.z2; z++) {
          positions.push([x, y, z]);
        }
      }
    }
    return positions;
  }

  moveDown() {
    this.z1--;
    this.z2--;
  }
}

function parseInput(input) {
  return input.trim().split('\n').map(line => new Brick(line));
}

function checkCollision(brick1, brick2) {
  return (
    brick1.x1 <= brick2.x2 && brick1.x2 >= brick2.x1 &&
    brick1.y1 <= brick2.y2 && brick1.y2 >= brick2.y1 &&
    brick1.z1 <= brick2.z2 && brick1.z2 >= brick2.z1
  );
}

function settleBricks(bricks) {
  bricks.sort((a, b) => a.z1 - b.z1);
  
  for (let i = 0; i < bricks.length; i++) {
    let brick = bricks[i];
    while (brick.z1 > 1) {
      brick.moveDown();
      let collision = false;
      for (let j = 0; j < i; j++) {
        if (checkCollision(brick, bricks[j])) {
          collision = true;
          break;
        }
      }
      if (collision) {
        brick.z1++;
        brick.z2++;
        break;
      }
    }
  }
  return bricks;
}

function findSupportRelations(bricks) {
  const supportedBy = new Map();
  const supports = new Map();

  bricks.forEach((upper, i) => {
    supportedBy.set(i, new Set());
    supports.set(i, new Set());
  });

  for (let i = 0; i < bricks.length; i++) {
    const upper = bricks[i];
    for (let j = 0; j < i; j++) {
      const lower = bricks[j];
      if (
        checkCollision(
          new Brick(`${upper.x1},${upper.y1},${upper.z1-1}~${upper.x2},${upper.y2},${upper.z1-1}`),
          lower
        )
      ) {
        supportedBy.get(i).add(j);
        supports.get(j).add(i);
      }
    }
  }

  return { supportedBy, supports };
}

function countFallingBricks(brickIndex, bricks, supportedBy, supports) {
  const falling = new Set([brickIndex]);
  let check = [brickIndex];

  while (check.length > 0) {
    const current = check.pop();
    for (const supported of supports.get(current)) {
      if (!falling.has(supported)) {
        const supporters = Array.from(supportedBy.get(supported));
        if (supporters.every(s => falling.has(s))) {
          falling.add(supported);
          check.push(supported);
        }
      }
    }
  }

  return falling.size - 1; // Subtract 1 to not count the disintegrated brick
}

export default function solution(input, returnAll = false) {
  const bricks = parseInput(input);
  const settledBricks = settleBricks(bricks);
  const { supportedBy, supports } = findSupportRelations(settledBricks);
  
  const fallingCounts = settledBricks.map((_, i) => 
    countFallingBricks(i, settledBricks, supportedBy, supports)
  );

  if (returnAll) {
    return fallingCounts;
  }
  
  return fallingCounts.reduce((sum, count) => sum + count, 0);
}