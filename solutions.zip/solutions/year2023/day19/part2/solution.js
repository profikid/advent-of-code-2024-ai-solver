// Parse input
function parseInput(input) {
  const [workflowsStr, partsStr] = input.trim().split('\n\n');
  const workflows = {};
  
  workflowsStr.split('\n').forEach(line => {
    const [name, rulesStr] = line.split('{');
    const rules = rulesStr.slice(0, -1).split(',').map(rule => {
      const colonIndex = rule.indexOf(':');
      if (colonIndex === -1) return { destination: rule };
      
      const condition = rule.slice(0, colonIndex);
      const destination = rule.slice(colonIndex + 1);
      const operator = condition.includes('<') ? '<' : '>';
      const [category, value] = condition.split(operator);
      
      return {
        category,
        operator,
        value: parseInt(value),
        destination
      };
    });
    workflows[name] = rules;
  });
  
  return { workflows };
}

// Check if a range will be accepted by following the workflow rules
function countAcceptedCombinations(workflows, workflow, ranges) {
  if (workflow === 'R') return 0n;
  if (workflow === 'A') {
    let product = 1n;
    for (const [min, max] of Object.values(ranges)) {
      product *= BigInt(max - min + 1);
    }
    return product;
  }

  let total = 0n;
  let currentRanges = { ...ranges };

  for (const rule of workflows[workflow]) {
    if (!rule.category) {
      // Last rule without condition
      total += countAcceptedCombinations(workflows, rule.destination, currentRanges);
      continue;
    }

    const { category, operator, value, destination } = rule;
    const [min, max] = currentRanges[category];

    // Split range based on condition
    if (operator === '<') {
      if (min < value) {
        // Part that satisfies the condition
        const matchingRanges = { ...currentRanges, [category]: [min, value - 1] };
        total += countAcceptedCombinations(workflows, destination, matchingRanges);
      }
      if (max >= value) {
        // Part that continues to next rule
        currentRanges = { ...currentRanges, [category]: [value, max] };
      } else {
        break;
      }
    } else { // operator === '>'
      if (max > value) {
        // Part that satisfies the condition
        const matchingRanges = { ...currentRanges, [category]: [value + 1, max] };
        total += countAcceptedCombinations(workflows, destination, matchingRanges);
      }
      if (min <= value) {
        // Part that continues to next rule
        currentRanges = { ...currentRanges, [category]: [min, value] };
      } else {
        break;
      }
    }
  }

  return total;
}

export default function solution(input) {
  const { workflows } = parseInput(input);
  
  // Initialize ranges for all categories (1 to 4000)
  const initialRanges = {
    x: [1, 4000],
    m: [1, 4000],
    a: [1, 4000],
    s: [1, 4000]
  };
  
  return Number(countAcceptedCombinations(workflows, 'in', initialRanges));
}