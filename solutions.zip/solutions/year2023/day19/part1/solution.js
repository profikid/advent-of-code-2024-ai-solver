export default function solution(input, returnDetails = false) {
    // Parse input into workflows and parts
    const [workflowsStr, partsStr] = input.trim().split('\n\n');
    const workflows = {};
    const parts = [];

    // Parse workflows
    workflowsStr.split('\n').forEach(line => {
        const [name, rulesStr] = line.split('{');
        const rules = rulesStr.slice(0, -1).split(',').map(rule => {
            if (!rule.includes(':')) return { destination: rule };
            const [condition, destination] = rule.split(':');
            const operator = condition.includes('<') ? '<' : '>';
            const [category, value] = condition.split(operator);
            return {
                category,
                operator,
                value: parseInt(value),
                destination
            };
        });
        workflows[name] = rules;
    });

    // Parse parts
    partsStr.split('\n').forEach(line => {
        const part = {};
        line.slice(1, -1).split(',').forEach(rating => {
            const [category, value] = rating.split('=');
            part[category] = parseInt(value);
        });
        parts.push(part);
    });

    // Process a part through workflows
    function processPart(part) {
        let currentWorkflow = 'in';
        
        while (true) {
            if (currentWorkflow === 'A') return true;
            if (currentWorkflow === 'R') return false;

            const rules = workflows[currentWorkflow];
            
            for (const rule of rules) {
                if (!rule.operator) {
                    currentWorkflow = rule.destination;
                    break;
                }

                const partValue = part[rule.category];
                const matches = rule.operator === '<' 
                    ? partValue < rule.value 
                    : partValue > rule.value;

                if (matches) {
                    currentWorkflow = rule.destination;
                    break;
                }
            }
        }
    }

    // Process all parts and calculate sum
    const acceptedParts = parts
        .filter(part => processPart(part))
        .map(part => part.x + part.m + part.a + part.s);

    if (returnDetails) {
        return { acceptedParts };
    }

    return acceptedParts.reduce((sum, value) => sum + value, 0);
}