const cardValues = {
    'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10,
    '9': 9, '8': 8, '7': 7, '6': 6, '5': 5, '4': 4, '3': 3, '2': 2
};

function getHandType(hand) {
    const counts = new Map();
    for (const card of hand) {
        counts.set(card, (counts.get(card) || 0) + 1);
    }
    
    const frequencies = Array.from(counts.values()).sort((a, b) => b - a);
    
    // Five of a kind
    if (frequencies[0] === 5) return 7;
    // Four of a kind
    if (frequencies[0] === 4) return 6;
    // Full house
    if (frequencies[0] === 3 && frequencies[1] === 2) return 5;
    // Three of a kind
    if (frequencies[0] === 3) return 4;
    // Two pair
    if (frequencies[0] === 2 && frequencies[1] === 2) return 3;
    // One pair
    if (frequencies[0] === 2) return 2;
    // High card
    return 1;
}

function compareHands(hand1, hand2) {
    const type1 = getHandType(hand1);
    const type2 = getHandType(hand2);
    
    if (type1 !== type2) {
        return type1 - type2;
    }
    
    // If types are equal, compare cards one by one
    for (let i = 0; i < hand1.length; i++) {
        if (hand1[i] !== hand2[i]) {
            return cardValues[hand1[i]] - cardValues[hand2[i]];
        }
    }
    return 0;
}

export default function solution(input) {
    const hands = input.trim().split('\n').map(line => {
        const [hand, bid] = line.split(' ');
        return { hand, bid: parseInt(bid, 10) };
    });

    // Sort hands based on their strength
    hands.sort((a, b) => compareHands(a.hand, b.hand));

    // Calculate total winnings
    const totalWinnings = hands.reduce((sum, hand, index) => {
        return sum + hand.bid * (index + 1);
    }, 0);

    return totalWinnings;
}

// Export helper functions for testing
solution.getHandType = getHandType;
solution.compareHands = compareHands;