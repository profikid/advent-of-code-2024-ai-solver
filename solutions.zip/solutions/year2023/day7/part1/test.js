import solution from './solution.js';

describe('Day 7: Camel Cards - Part 1', () => {
    const input = `32T3K 765
T55J5 684
KK677 28
KTJJT 220
QQQJA 483`;

    it('should calculate total winnings based on hand ranks', () => {
        expect(solution(input)).toBe(6440);
    });

    it('should correctly identify hand types', () => {
        // Testing individual hands
        const cases = [
            ['AAAAA', 7], // Five of a kind
            ['AA8AA', 6], // Four of a kind
            ['23332', 5], // Full house
            ['TTT98', 4], // Three of a kind
            ['23432', 3], // Two pair
            ['A23A4', 2], // One pair
            ['23456', 1], // High card
        ];
        
        cases.forEach(([hand, expectedType]) => {
            expect(solution.getHandType(hand)).toBe(expectedType);
        });
    });

    it('should correctly compare hands of same type', () => {
        expect(solution.compareHands('33332', '2AAAA')).toBeGreaterThan(0); // First card stronger
        expect(solution.compareHands('77888', '77788')).toBeGreaterThan(0); // Third card stronger
    });
});