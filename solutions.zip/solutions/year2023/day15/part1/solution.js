// Helper function to calculate HASH value for a string
function calculateHash(str) {
  let currentValue = 0;
  
  for (let i = 0; i < str.length; i++) {
    // Get ASCII code
    const asciiCode = str.charCodeAt(i);
    // Increase current value by ASCII code
    currentValue += asciiCode;
    // Multiply by 17
    currentValue *= 17;
    // Get remainder of division by 256
    currentValue %= 256;
  }
  
  return currentValue;
}

export default function solution(input) {
  // Split input by commas, ignoring newlines
  const steps = input.trim().split(',');
  
  // Calculate hash for each step and sum the results
  const sum = steps.reduce((acc, step) => acc + calculateHash(step), 0);
  
  return sum;
}

// Export calculateHash for testing
solution.calculateHash = calculateHash;