import solution from './solution.js';

describe('Day 15: Lens Library - Part 1', () => {
  it('should calculate HASH of individual strings', () => {
    // Test each individual HASH from example
    const cases = [
      ['rn=1', 30],
      ['cm-', 253],
      ['qp=3', 97],
      ['cm=2', 47],
      ['qp-', 14],
      ['pc=4', 180],
      ['ot=9', 9],
      ['ab=5', 197],
      ['pc-', 48],
      ['pc=6', 214],
      ['ot=7', 231],
    ];

    cases.forEach(([input, expected]) => {
      expect(solution.calculateHash(input)).toBe(expected);
    });
  });

  it('should sum all HASH results from initialization sequence', () => {
    const input = 'rn=1,cm-,qp=3,cm=2,qp-,pc=4,ot=9,ab=5,pc-,pc=6,ot=7';
    expect(solution(input)).toBe(1320);
  });
});