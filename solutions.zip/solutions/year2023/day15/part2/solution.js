function calculateHash(str) {
  let currentValue = 0;
  for (let i = 0; i < str.length; i++) {
    currentValue += str.charCodeAt(i);
    currentValue *= 17;
    currentValue %= 256;
  }
  return currentValue;
}

export default function solution(input) {
  const steps = input.trim().split(',');
  const boxes = Array.from({ length: 256 }, () => []);

  // Process each step
  for (const step of steps) {
    if (step.includes('=')) {
      // Add or replace lens
      const [label, focalLength] = step.split('=');
      const boxNumber = calculateHash(label);
      const existingLensIndex = boxes[boxNumber].findIndex(lens => lens.label === label);
      
      if (existingLensIndex !== -1) {
        // Replace existing lens
        boxes[boxNumber][existingLensIndex] = { label, focalLength: parseInt(focalLength) };
      } else {
        // Add new lens to the back
        boxes[boxNumber].push({ label, focalLength: parseInt(focalLength) });
      }
    } else if (step.includes('-')) {
      // Remove lens
      const label = step.slice(0, -1);
      const boxNumber = calculateHash(label);
      const existingLensIndex = boxes[boxNumber].findIndex(lens => lens.label === label);
      
      if (existingLensIndex !== -1) {
        boxes[boxNumber].splice(existingLensIndex, 1);
      }
    }
  }

  // Calculate focusing power
  let totalPower = 0;
  for (let boxNum = 0; boxNum < boxes.length; boxNum++) {
    const box = boxes[boxNum];
    for (let slot = 0; slot < box.length; slot++) {
      const focusingPower = (1 + boxNum) * (slot + 1) * box[slot].focalLength;
      totalPower += focusingPower;
    }
  }

  return totalPower;
}