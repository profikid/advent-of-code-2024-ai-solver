export default function solution(input) {
    // Split input into patterns
    const patterns = input.trim().split('\n\n');
    
    let total = 0;
    
    for (const pattern of patterns) {
        const lines = pattern.split('\n');
        
        // Try to find horizontal reflection
        const horizontalValue = findHorizontalReflection(lines);
        if (horizontalValue !== -1) {
            total += horizontalValue * 100;
            continue;
        }
        
        // If no horizontal reflection found, try vertical
        const verticalValue = findVerticalReflection(lines);
        if (verticalValue !== -1) {
            total += verticalValue;
        }
    }
    
    return total;
}

function findHorizontalReflection(lines) {
    // For each possible reflection line (between rows)
    for (let i = 1; i < lines.length; i++) {
        let isReflection = true;
        let up = i - 1;
        let down = i;
        
        // Check all pairs of rows moving outward
        while (up >= 0 && down < lines.length) {
            if (lines[up] !== lines[down]) {
                isReflection = false;
                break;
            }
            up--;
            down++;
        }
        
        if (isReflection) {
            return i;  // Return number of rows above reflection
        }
    }
    return -1;
}

function findVerticalReflection(lines) {
    // Convert lines to columns
    const width = lines[0].length;
    const columns = [];
    
    for (let x = 0; x < width; x++) {
        let column = '';
        for (let y = 0; y < lines.length; y++) {
            column += lines[y][x];
        }
        columns.push(column);
    }
    
    // For each possible reflection line (between columns)
    for (let i = 1; i < columns.length; i++) {
        let isReflection = true;
        let left = i - 1;
        let right = i;
        
        // Check all pairs of columns moving outward
        while (left >= 0 && right < columns.length) {
            if (columns[left] !== columns[right]) {
                isReflection = false;
                break;
            }
            left--;
            right++;
        }
        
        if (isReflection) {
            return i;  // Return number of columns to the left of reflection
        }
    }
    return -1;
}