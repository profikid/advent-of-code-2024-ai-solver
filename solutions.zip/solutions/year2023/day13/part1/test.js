import solution from './solution.js';

describe('Day 13: Point of Incidence - Part 1', () => {
    test('should find reflection lines and calculate summary', () => {
        const input = `#.##..##.
..#.##.#.
##......#
##......#
..#.##.#.
..##..##.
#.#.##.#.

#...##..#
#....#..#
..##..###
#####.##.
#####.##.
..##..###
#....#..#`;

        expect(solution(input)).toBe(405);
    });

    test('handles vertical reflection - first pattern', () => {
        const input = `#.##..##.
..#.##.#.
##......#
##......#
..#.##.#.
..##..##.
#.#.##.#.`;
        
        expect(solution(input)).toBe(5);
    });

    test('handles horizontal reflection - second pattern', () => {
        const input = `#...##..#
#....#..#
..##..###
#####.##.
#####.##.
..##..###
#....#..#`;
        
        expect(solution(input)).toBe(400);
    });
});