I've created a complete solution for Day 13 Part 1. Let me explain the approach:

1. First, I created tests that cover:
   - The main example from the puzzle
   - Individual tests for vertical and horizontal reflection patterns
   - Proper handling of the summary calculation (columns + 100 * rows)

2. The solution works by:
   - Splitting the input into separate patterns by double newlines
   - For each pattern:
     - First trying to find a horizontal reflection line
     - If no horizontal reflection is found, trying to find a vertical reflection line
     - Adding the appropriate value to the total (column count or 100 * row count)

3. Key functions:
   - `findHorizontalReflection`: Looks for matching rows moving outward from each possible reflection line
   - `findVerticalReflection`: Converts the pattern to columns and then uses the same logic as horizontal reflection

4. The code handles edge cases by:
   - Properly checking bounds when looking for reflections
   - Ensuring complete matches for the reflection pattern
   - Returning -1 when no reflection is found
   - Trimming input to handle any extra whitespace

5. The solve.js file processes the real input and saves the result to output.txt

The solution passed all the tests and should correctly handle the puzzle input. The code is clean, handles edge cases, and follows ES6 module syntax as requested.