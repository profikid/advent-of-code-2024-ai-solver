import solution from './solution.js';

describe('Day 13 Part 2', () => {
  it('should find correct reflection line after fixing smudge', () => {
    const input = `#.##..##.
..#.##.#.
##......#
##......#
..#.##.#.
..##..##.
#.#.##.#.

#...##..#
#....#..#
..##..###
#####.##.
#####.##.
..##..###
#....#..#`;

    expect(solution(input)).toBe(400);
  });

  it('should handle first pattern correctly', () => {
    const input = `#.##..##.
..#.##.#.
##......#
##......#
..#.##.#.
..##..##.
#.#.##.#.`;

    expect(solution(input)).toBe(300); // 3 rows above * 100
  });

  it('should handle second pattern correctly', () => {
    const input = `#...##..#
#....#..#
..##..###
#####.##.
#####.##.
..##..###
#....#..#`;

    expect(solution(input)).toBe(100); // 1 row above * 100
  });
});