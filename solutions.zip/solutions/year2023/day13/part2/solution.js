function findReflections(pattern) {
  const rows = pattern.split('\n');
  const height = rows.length;
  const width = rows[0].length;
  
  // Get column as string
  const getColumn = (colIndex) => {
    return rows.map(row => row[colIndex]).join('');
  };

  // Check if there's a reflection between two indices with one allowed difference
  const isReflectionWithSmudge = (arr, startIdx, isHorizontal) => {
    let differences = 0;
    let steps = Math.min(startIdx + 1, arr.length - startIdx - 1);
    
    for (let i = 0; i < steps; i++) {
      const a = arr[startIdx - i];
      const b = arr[startIdx + 1 + i];
      
      // Count character differences
      if (a && b) {
        for (let j = 0; j < a.length; j++) {
          if (a[j] !== b[j]) differences++;
        }
      }
    }
    
    return differences === 1;
  };

  // Find horizontal reflections
  let oldHorizontal = null;
  for (let i = 0; i < height - 1; i++) {
    let isExactMatch = true;
    let steps = Math.min(i + 1, height - i - 1);
    
    for (let j = 0; j < steps; j++) {
      if (rows[i - j] !== rows[i + 1 + j]) {
        isExactMatch = false;
        break;
      }
    }
    
    if (isExactMatch) {
      oldHorizontal = i + 1;
    }
  }
  
  // Find vertical reflections
  let oldVertical = null;
  const columns = Array.from({ length: width }, (_, i) => getColumn(i));
  for (let i = 0; i < width - 1; i++) {
    let isExactMatch = true;
    let steps = Math.min(i + 1, width - i - 1);
    
    for (let j = 0; j < steps; j++) {
      if (columns[i - j] !== columns[i + 1 + j]) {
        isExactMatch = false;
        break;
      }
    }
    
    if (isExactMatch) {
      oldVertical = i + 1;
    }
  }

  // Find new reflection with smudge
  // Check horizontal
  for (let i = 0; i < height - 1; i++) {
    if (i + 1 === oldHorizontal) continue;
    if (isReflectionWithSmudge(rows, i, true)) {
      return (i + 1) * 100;
    }
  }

  // Check vertical
  for (let i = 0; i < width - 1; i++) {
    if (i + 1 === oldVertical) continue;
    if (isReflectionWithSmudge(columns, i, false)) {
      return i + 1;
    }
  }
}

export default function solution(input) {
  const patterns = input.trim().split('\n\n');
  return patterns.reduce((sum, pattern) => sum + findReflections(pattern), 0);
}