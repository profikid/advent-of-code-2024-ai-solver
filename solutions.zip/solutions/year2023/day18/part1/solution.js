export default function solution(input) {
    // Parse the dig plan instructions
    const instructions = input.trim().split('\n').map(line => {
        const [direction, steps, color] = line.match(/([UDLR]) (\d+) \((#[0-9a-f]{6})\)/).slice(1);
        return { direction, steps: parseInt(steps), color };
    });

    // Find the dimensions of the grid needed
    let minX = 0, maxX = 0, minY = 0, maxY = 0;
    let x = 0, y = 0;

    // First pass to determine grid size
    instructions.forEach(({ direction, steps }) => {
        switch(direction) {
            case 'R': x += steps; break;
            case 'L': x -= steps; break;
            case 'U': y -= steps; break;
            case 'D': y += steps; break;
        }
        minX = Math.min(minX, x);
        maxX = Math.max(maxX, x);
        minY = Math.min(minY, y);
        maxY = Math.max(maxY, y);
    });

    // Create grid with padding
    const width = maxX - minX + 3;
    const height = maxY - minY + 3;
    const grid = Array(height).fill().map(() => Array(width).fill('.'));

    // Plot the trench
    x = -minX + 1;
    y = -minY + 1;
    grid[y][x] = '#';

    instructions.forEach(({ direction, steps }) => {
        for (let i = 0; i < steps; i++) {
            switch(direction) {
                case 'R': x++; break;
                case 'L': x--; break;
                case 'U': y--; break;
                case 'D': y++; break;
            }
            grid[y][x] = '#';
        }
    });

    // Flood fill from outside
    const floodFill = (startX, startY) => {
        const stack = [[startX, startY]];
        while (stack.length > 0) {
            const [cx, cy] = stack.pop();
            if (cx < 0 || cy < 0 || cx >= width || cy >= height || grid[cy][cx] !== '.') continue;
            grid[cy][cx] = 'O';
            stack.push([cx + 1, cy], [cx - 1, cy], [cx, cy + 1], [cx, cy - 1]);
        }
    };

    // Start flood fill from corner
    floodFill(0, 0);

    // Count interior and border cells
    let count = 0;
    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            if (grid[y][x] !== 'O') {
                count++;
            }
        }
    }

    return count;
}