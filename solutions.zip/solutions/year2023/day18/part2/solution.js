export default function solution(input) {
  if (!input) return '0';
  
  const instructions = input.trim().split('\n').map(line => {
    const match = line.match(/[RDLU]\s+\d+\s+\(#([a-f0-9]{6})\)/);
    if (!match) return null;
    
    const hex = match[1];
    const distance = parseInt(hex.slice(0, 5), 16);
    const direction = ['R', 'D', 'L', 'U'][parseInt(hex[5], 16)];
    
    return { direction, distance };
  }).filter(Boolean);

  if (instructions.length <= 1) return '0';

  // Using shoelace formula + Pick's theorem
  const vertices = [];
  let currentX = 0;
  let currentY = 0;
  let perimeter = 0;

  // Collect vertices and calculate perimeter
  vertices.push([currentX, currentY]);
  
  for (const { direction, distance } of instructions) {
    perimeter += distance;
    
    switch (direction) {
      case 'R':
        currentX += distance;
        break;
      case 'L':
        currentX -= distance;
        break;
      case 'U':
        currentY -= distance;
        break;
      case 'D':
        currentY += distance;
        break;
    }
    vertices.push([currentX, currentY]);
  }

  // Calculate area using shoelace formula
  let area = 0;
  for (let i = 0; i < vertices.length - 1; i++) {
    area += vertices[i][0] * vertices[i + 1][1] - vertices[i + 1][0] * vertices[i][1];
  }
  area = Math.abs(area) / 2;

  // Use Pick's theorem to get the total points
  // area = i + b/2 - 1 where i is interior points and b is boundary points
  // Total points = i + b = area + b/2 + 1
  const totalPoints = area + perimeter / 2 + 1;

  return totalPoints.toString();
}