export default function solution(input) {
  // Parse input into structured data
  const cards = input.split('\n').map(line => {
    const [cardInfo, numbers] = line.split(': ');
    const [winningStr, haveStr] = numbers.split(' | ');
    const winning = winningStr.trim().split(/\s+/).map(n => parseInt(n));
    const have = haveStr.trim().split(/\s+/).map(n => parseInt(n));
    return { winning, have };
  });

  // Part 1: Calculate points
  const part1 = cards.reduce((sum, card) => {
    const matches = card.have.filter(n => card.winning.includes(n)).length;
    if (matches === 0) return sum;
    return sum + Math.pow(2, matches - 1);
  }, 0);

  // Part 2: Calculate total scratchcards
  const cardCounts = new Array(cards.length).fill(1);
  
  for (let i = 0; i < cards.length; i++) {
    const matches = cards[i].have.filter(n => cards[i].winning.includes(n)).length;
    // For each match, add copies to subsequent cards
    for (let j = 1; j <= matches && i + j < cards.length; j++) {
      cardCounts[i + j] += cardCounts[i];
    }
  }

  const part2 = cardCounts.reduce((sum, count) => sum + count, 0);

  return { part1, part2 };
}