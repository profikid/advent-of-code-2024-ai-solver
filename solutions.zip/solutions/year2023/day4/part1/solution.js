export default function solution(input) {
    return input.split('\n')
        .map(line => {
            // Extract numbers after the colon and split by |
            const [_, numbers] = line.split(':');
            if (!numbers) return 0;
            
            const [winningStr, haveStr] = numbers.split('|');
            
            // Convert strings to arrays of numbers, filtering out empty strings
            const winning = winningStr.trim().split(/\s+/).map(Number);
            const have = haveStr.trim().split(/\s+/).map(Number);
            
            // Count matches
            const matches = have.filter(num => winning.includes(num)).length;
            
            // Calculate points: 1 point for first match, doubled for each additional match
            return matches > 0 ? Math.pow(2, matches - 1) : 0;
        })
        .reduce((sum, points) => sum + points, 0);
}