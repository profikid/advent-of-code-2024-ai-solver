export default function solution(input) {
    if (!input || !input.trim()) {
        throw new Error('Input is required');
    }

    const grid = input.split('\n').map(line => line.split(''));
    const height = grid.length;
    const width = grid[0].length;

    // Validate input dimensions
    if (height < 3 || width < 3) {
        throw new Error('Invalid grid dimensions');
    }

    // Find start and end positions
    const start = { x: grid[0].indexOf('.'), y: 0 };
    const end = { x: grid[height - 1].indexOf('.'), y: height - 1 };

    // Directions: right, down, left, up
    const directions = [
        { x: 1, y: 0 },
        { x: 0, y: 1 },
        { x: -1, y: 0 },
        { x: 0, y: -1 }
    ];

    const slopes = {
        '>': { x: 1, y: 0 },
        'v': { x: 0, y: 1 },
        '<': { x: -1, y: 0 },
        '^': { x: 0, y: -1 }
    };

    function isInBounds(x, y) {
        return x >= 0 && x < width && y >= 0 && y < height;
    }

    function findLongestPath(pos, visited = new Set()) {
        if (pos.y === end.y && pos.x === end.x) {
            return visited.size;
        }

        let maxLength = -1;
        const currentPos = `${pos.x},${pos.y}`;
        visited.add(currentPos);

        const currentTile = grid[pos.y][pos.x];
        
        // If we're on a slope, we must follow it
        if (slopes[currentTile]) {
            const dir = slopes[currentTile];
            const newX = pos.x + dir.x;
            const newY = pos.y + dir.y;

            if (isInBounds(newX, newY) && grid[newY][newX] !== '#' && !visited.has(`${newX},${newY}`)) {
                const length = findLongestPath({ x: newX, y: newY }, new Set(visited));
                if (length > maxLength) maxLength = length;
            }
        } else {
            // Try all possible directions
            for (const dir of directions) {
                const newX = pos.x + dir.x;
                const newY = pos.y + dir.y;

                if (!isInBounds(newX, newY) || grid[newY][newX] === '#' || visited.has(`${newX},${newY}`)) {
                    continue;
                }

                const length = findLongestPath({ x: newX, y: newY }, new Set(visited));
                if (length > maxLength) maxLength = length;
            }
        }

        visited.delete(currentPos);
        return maxLength;
    }

    const longestPath = findLongestPath(start);
    return longestPath;
}