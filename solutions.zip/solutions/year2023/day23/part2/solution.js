export default function solution(input) {
  const grid = input.split('\n').map(line => line.split(''));
  const rows = grid.length;
  const cols = grid[0].length;
  
  const start = [0, 1];  // First row, second column (always)
  const end = [rows - 1, cols - 2];  // Last row, second to last column (always)
  
  // Find all intersections (points with more than 2 neighbors)
  const getNeighbors = (row, col) => {
    const neighbors = [];
    for (const [dr, dc] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
      const newRow = row + dr;
      const newCol = col + dc;
      if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols && grid[newRow][newCol] !== '#') {
        neighbors.push([newRow, newCol]);
      }
    }
    return neighbors;
  };

  const isIntersection = (pos) => {
    const [row, col] = pos;
    return grid[row][col] !== '#' && getNeighbors(row, col).length > 2;
  };

  // Find all intersections including start and end
  const intersections = new Set([`${start[0]},${start[1]}`, `${end[0]},${end[1]}`]);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (isIntersection([r, c])) {
        intersections.add(`${r},${c}`);
      }
    }
  }

  // Build a graph of distances between intersections
  const graph = new Map();
  
  for (const intersection of intersections) {
    const [startR, startC] = intersection.split(',').map(Number);
    const queue = [[startR, startC, 0, new Set([`${startR},${startC}`])]];
    const distances = new Map();
    
    while (queue.length > 0) {
      const [r, c, dist, seen] = queue.shift();
      
      if (dist > 0 && intersections.has(`${r},${c}`)) {
        if (!graph.has(intersection)) {
          graph.set(intersection, []);
        }
        graph.get(intersection).push([`${r},${c}`, dist]);
        continue;
      }
      
      for (const [newR, newC] of getNeighbors(r, c)) {
        const key = `${newR},${newC}`;
        if (!seen.has(key)) {
          const newSeen = new Set(seen);
          newSeen.add(key);
          queue.push([newR, newC, dist + 1, newSeen]);
        }
      }
    }
  }

  // DFS to find longest path
  function dfs(node, visited) {
    if (node === `${end[0]},${end[1]}`) {
      return 0;
    }
    
    let maxLength = -Infinity;
    const neighbors = graph.get(node) || [];
    
    for (const [next, dist] of neighbors) {
      if (!visited.has(next)) {
        visited.add(next);
        const length = dfs(next, visited);
        visited.delete(next);
        
        if (length !== -Infinity) {
          maxLength = Math.max(maxLength, length + dist);
        }
      }
    }
    
    return maxLength;
  }

  const startVisited = new Set([`${start[0]},${start[1]}`]);
  return dfs(`${start[0]},${start[1]}`, startVisited);
}