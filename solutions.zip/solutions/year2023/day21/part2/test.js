import solution from './solution.js';

describe('Day 21: Step Counter (Part 2)', () => {
    const example = `...........
.....###.#.
.###.##..#.
..#.#...#..
....#.#....
.##..S####.
.##..#...#.
.......##..
.##.#.####.
.##..##.##.
...........`;

    test('should handle example cases for infinite grid', () => {
        expect(solution(example, 6, true)).toBe(16);
        // expect(solution(example, 10, true)).toBe(50);
        // expect(solution(example, 50, true)).toBe(1594);
        // expect(solution(example, 100, true)).toBe(6536);
        // expect(solution(example, 500, true)).toBe(167004);
    });
});