export default function solution(input, steps = 26501365, isInfinite = true) {
    const grid = input.split('\n').map(row => row.split(''));
    const height = grid.length;
    const width = grid[0].length;

    // Find starting position
    let start = { x: 0, y: 0 };
    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            if (grid[y][x] === 'S') {
                start = { x, y };
                grid[y][x] = '.';
                break;
            }
        }
    }

    const directions = [[0, 1], [1, 0], [0, -1], [-1, 0]];
    
    // Use Set to store positions as strings "x,y"
    let positions = new Set([`${start.x},${start.y}`]);
    
    function getCell(x, y) {
        if (!isInfinite) {
            return x >= 0 && x < width && y >= 0 && y < height ? grid[y][x] : '#';
        }
        // For infinite grid, wrap around
        const wrappedY = ((y % height) + height) % height;
        const wrappedX = ((x % width) + width) % width;
        return grid[wrappedY][wrappedX];
    }

    // For part 2, we need to detect patterns in the growth
    if (isInfinite && steps > 1000) {
        // The input is specifically crafted so that:
        // - The grid size is odd (131x131)
        // - The starting point is in the center
        // - The number of steps (26501365) is 202300 * 131 + 65
        // This creates a quadratic pattern
        
        const gridSize = width;
        const halfGrid = Math.floor(gridSize / 2);
        const fullCycles = Math.floor(steps / gridSize);
        const remainder = steps % gridSize;
        
        // We need three points to determine the quadratic formula
        const points = [];
        for (let n = 0; n < 3; n++) {
            positions = new Set([`${start.x},${start.y}`]);
            const stepsToTake = remainder + n * gridSize;
            
            for (let step = 0; step < stepsToTake; step++) {
                const newPositions = new Set();
                for (const pos of positions) {
                    const [x, y] = pos.split(',').map(Number);
                    for (const [dx, dy] of directions) {
                        const newX = x + dx;
                        const newY = y + dy;
                        if (getCell(newX, newY) === '.') {
                            newPositions.add(`${newX},${newY}`);
                        }
                    }
                }
                positions = newPositions;
            }
            points.push(positions.size);
        }

        // Solve quadratic equation using the three points
        const [y0, y1, y2] = points;
        const a = (y2 - 2 * y1 + y0) / 2;
        const b = (-3 * y0 + 4 * y1 - y2) / 2;
        const c = y0;
        
        // Calculate result for the actual number of cycles
        const n = fullCycles;
        return a * n * n + b * n + c;
    }

    // For part 1 or smaller step counts in part 2
    for (let step = 0; step < steps; step++) {
        const newPositions = new Set();
        for (const pos of positions) {
            const [x, y] = pos.split(',').map(Number);
            for (const [dx, dy] of directions) {
                const newX = x + dx;
                const newY = y + dy;
                if (getCell(newX, newY) === '.') {
                    newPositions.add(`${newX},${newY}`);
                }
            }
        }
        positions = newPositions;
    }

    return positions.size;
}