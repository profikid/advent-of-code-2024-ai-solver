I've implemented the solution for Day 21 Part 2. This was a challenging puzzle that required identifying and utilizing a mathematical pattern. Here's how the solution works:

1. The solution handles both finite (Part 1) and infinite (Part 2) grids.
2. For the infinite grid case with large step counts:
   - The input is specifically crafted so that the starting point is in the center of a 131x131 grid
   - The target step count (26501365) follows a pattern: it's 202300 * 131 + 65
   - This creates a quadratic pattern in the number of reachable plots
3. The solution:
   - For small step counts, it directly simulates the movement
   - For large step counts, it:
     - Calculates three points to determine the quadratic formula
     - Uses these points to find coefficients a, b, c of the quadratic equation
     - Plugs in the actual number of cycles to get the final answer

The solution handles all the example cases correctly (6 steps = 16 plots, 10 steps = 50 plots, etc.) and should work for the massive step count in Part 2.

Some key optimizations:
- Uses Sets to store positions and avoid duplicates
- Implements efficient grid wrapping for the infinite case
- Leverages the mathematical pattern instead of trying to simulate all steps

The test file verifies the example cases for the infinite grid version, and the solve script applies the solution to the actual input with the full step count.