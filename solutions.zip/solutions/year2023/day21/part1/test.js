import solution from './solution.js';

describe('Day 21 Part 1', () => {
    const input = `...........
.....###.#.
.###.##..#.
..#.#...#..
....#.#....
.##..S####.
.##..#...#.
.......##..
.##.#.####.
.##..##.##.
...........`;

    test('should return number of garden plots reachable in 6 steps', () => {
        expect(solution(input, 6)).toBe(16);
    });

    test('handles empty input', () => {
        expect(solution('', 64)).toBe(0);
    });

    test('handles invalid input', () => {
        expect(solution('ABC', 64)).toBe(0);
    });
});