export default function solution(input, steps = 64) {
    if (!input || !input.trim()) return 0;

    // Parse the input into a grid
    const grid = input.trim().split('\n').map(line => line.split(''));
    const height = grid.length;
    const width = grid[0].length;

    // Find starting position
    let start = { x: 0, y: 0 };
    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            if (grid[y][x] === 'S') {
                start = { x, y };
                grid[y][x] = '.'; // Convert S to garden plot
                break;
            }
        }
    }

    // Directions for movement
    const directions = [
        { x: 0, y: -1 }, // up
        { x: 0, y: 1 },  // down
        { x: -1, y: 0 }, // left
        { x: 1, y: 0 }   // right
    ];

    // Use Set to track positions reachable at current step
    let currentPositions = new Set([`${start.x},${start.y}`]);

    // For each step
    for (let step = 0; step < steps; step++) {
        const nextPositions = new Set();

        // For each current position
        for (const pos of currentPositions) {
            const [x, y] = pos.split(',').map(Number);

            // Try each direction
            for (const dir of directions) {
                const newX = x + dir.x;
                const newY = y + dir.y;

                // Check if the new position is valid and is a garden plot
                if (newX >= 0 && newX < width && 
                    newY >= 0 && newY < height && 
                    grid[newY][newX] === '.') {
                    nextPositions.add(`${newX},${newY}`);
                }
            }
        }

        currentPositions = nextPositions;
    }

    return currentPositions.size;
}