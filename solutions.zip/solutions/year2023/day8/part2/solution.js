function gcd(a, b) {
  while (b) {
    [a, b] = [b, a % b];
  }
  return a;
}

function lcm(a, b) {
  return Math.abs(a * b) / gcd(a, b);
}

function lcmArray(arr) {
  return arr.reduce(lcm);
}

export default function solution(input) {
  if (!input) return 0;

  const lines = input.split('\n');
  const instructions = lines[0].trim();
  const nodes = {};

  // Parse the nodes
  for (let i = 2; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const [node, destinations] = line.split(' = ');
    const [left, right] = destinations.slice(1, -1).split(', ');
    nodes[node] = { L: left, R: right };
  }

  // Find all starting nodes (ending with A)
  const currentPositions = Object.keys(nodes).filter(node => node.endsWith('A'));
  
  if (currentPositions.length === 0) return 0;

  // Find the steps needed for each starting position to reach a Z node
  const cycles = currentPositions.map(startPos => {
    let pos = startPos;
    let steps = 0;
    let instructionIndex = 0;

    // Keep track of visited positions at specific instruction indices to detect cycles
    const visited = new Set();
    
    while (true) {
      const key = `${pos}-${instructionIndex}`;
      if (pos.endsWith('Z')) {
        return steps;
      }
      
      if (visited.has(key)) {
        return steps;
      }
      
      visited.add(key);
      
      const instruction = instructions[instructionIndex];
      pos = nodes[pos][instruction];
      steps++;
      
      instructionIndex = (instructionIndex + 1) % instructions.length;
    }
  });

  // The answer is the least common multiple of all cycles
  return lcmArray(cycles);
}