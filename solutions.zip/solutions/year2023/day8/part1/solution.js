export default function solution(input) {
    // Split input into instructions and network map
    const [instructions, networkPart] = input.split('\n\n');
    
    // Parse network map into an object
    const network = {};
    networkPart.split('\n').forEach(line => {
        if (line.trim() === '') return;
        const [node, paths] = line.split(' = ');
        const [left, right] = paths.replace('(', '').replace(')', '').split(', ');
        network[node.trim()] = {
            L: left.trim(),
            R: right.trim()
        };
    });

    // Initialize variables
    let currentNode = 'AAA';
    let steps = 0;
    let instructionIndex = 0;

    // Continue until we reach ZZZ
    while (currentNode !== 'ZZZ') {
        // Get current instruction (L or R)
        const instruction = instructions[instructionIndex];
        
        // Move to next node based on instruction
        currentNode = network[currentNode][instruction];
        
        // Increment steps
        steps++;
        
        // Move to next instruction, loop back to start if needed
        instructionIndex = (instructionIndex + 1) % instructions.length;
    }

    return steps;
}