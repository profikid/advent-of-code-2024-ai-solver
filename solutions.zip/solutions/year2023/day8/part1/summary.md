I've implemented the solution for Day 8 Part 1. Let me explain the solution step by step:

1. First, I created test cases for both example scenarios provided in the puzzle:
   - Example 1 with "RL" instructions that takes 2 steps
   - Example 2 with "LLR" instructions that takes 6 steps

2. The solution works as follows:
   - Split the input into two parts: instructions (L/R sequence) and network map
   - Parse the network map into an object where each node maps to its left and right destinations
   - Start at node 'AAA' and follow the instructions:
     * Use the current instruction (L/R) to determine which path to take
     * Keep track of steps taken
     * Loop through instructions if we run out (using modulo operator)
     * Continue until we reach 'ZZZ'

3. The solution handles edge cases:
   - Empty lines in the input
   - Proper trimming of whitespace and parentheses
   - Circular instruction pattern using modulo
   - Proper node lookup in the network map

4. The solve.js file was created to handle the actual puzzle input and write the result to output.txt

All tests pass successfully, and the solution correctly implements the requirements from the puzzle. The code is clean, handles edge cases, and follows ES6 module style.

Let me know if there's a Part 2 to implement or if you need any clarification about the solution!