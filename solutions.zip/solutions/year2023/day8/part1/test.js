import solution from './solution.js';

describe('Day 8: Haunted Wasteland - Part 1', () => {
    test('Example 1 - should take 2 steps to reach ZZZ', () => {
        const input = `RL

AAA = (BBB, CCC)
BBB = (DDD, EEE)
CCC = (ZZZ, GGG)
DDD = (DDD, DDD)
EEE = (EEE, EEE)
GGG = (GGG, GGG)
ZZZ = (ZZZ, ZZZ)`;
        
        expect(solution(input)).toBe(2);
    });

    test('Example 2 - should take 6 steps to reach ZZZ', () => {
        const input = `LLR

AAA = (BBB, BBB)
BBB = (AAA, ZZZ)
ZZZ = (ZZZ, ZZZ)`;
        
        expect(solution(input)).toBe(6);
    });
});