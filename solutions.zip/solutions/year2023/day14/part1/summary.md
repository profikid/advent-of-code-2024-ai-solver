I've implemented the solution for Day 14 Part 1. Let me explain the approach:

1. First, I created test cases that cover:
   - The example from the puzzle that should return 136
   - An edge case with empty input

2. The solution works in the following steps:
   - Parse the input into a 2D grid
   - Roll rocks north by:
     - Scanning each position
     - When finding an 'O', roll it up as far as possible until hitting another rock or wall
     - Update the grid with new positions
   - Calculate total load by:
     - For each 'O', add (total height - current row) to the total
     - This gives us the load based on distance from bottom

3. The main algorithm specifically:
   - Uses a nested loop to process each cell
   - For rolling rocks, checks upward positions until finding an obstacle
   - Moves rocks to their new positions by swapping characters
   - Calculates load based on position from bottom

4. Finally, created the solve.js that:
   - Reads the input file
   - Runs the solution
   - Saves the result

The solution handles edge cases and follows the rules exactly as specified in the puzzle. The test passes with the example case, and the solve script should now process the actual input correctly.

Let me know if you want me to explain any part in more detail or if you need the solution for Part 2!