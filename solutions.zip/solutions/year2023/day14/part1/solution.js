export default function solution(input) {
    if (!input) return 0;
    
    // Split input into grid
    const grid = input.split('\n').map(line => line.split(''));
    const height = grid.length;
    const width = grid[0].length;

    // Roll all rocks north
    for (let row = 0; row < height; row++) {
        for (let col = 0; col < width; col++) {
            if (grid[row][col] === 'O') {
                // Find the highest position this rock can roll to
                let newRow = row;
                while (newRow > 0 && grid[newRow - 1][col] === '.') {
                    newRow--;
                }
                
                // Move the rock if it can roll up
                if (newRow !== row) {
                    grid[newRow][col] = 'O';
                    grid[row][col] = '.';
                }
            }
        }
    }

    // Calculate total load
    let totalLoad = 0;
    for (let row = 0; row < height; row++) {
        for (let col = 0; col < width; col++) {
            if (grid[row][col] === 'O') {
                // Load is number of rows from bottom, including current row
                totalLoad += (height - row);
            }
        }
    }

    return totalLoad;
}