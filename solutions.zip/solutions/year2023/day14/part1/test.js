import solution from './solution.js';

describe('Day 14 Part 1', () => {
    it('should calculate total load of rocks after rolling north', () => {
        const input = `O....#....
O.OO#....#
.....##...
OO.#O....O
.O.....O#.
O.#..O.#.#
..O..#O..O
.......O..
#....###..
#OO..#....`;

        expect(solution(input)).toBe(136);
    });

    it('should handle empty input', () => {
        expect(solution('')).toBe(0);
    });
});