import solution from './solution.js';

describe('Day 14: Parabolic Reflector Dish (Part 2)', () => {
  test('should calculate total load after spin cycles', () => {
    const input = 
`O....#....
O.OO#....#
.....##...
OO.#O....O
.O.....O#.
O.#..O.#.#
..O..#O..O
.......O..
#....###..
#OO..#....`;

    expect(solution(input)).toBe(64);
  });

  test('should handle empty input', () => {
    expect(solution('')).toBe(0);
  });
});