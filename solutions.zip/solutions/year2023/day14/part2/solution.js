function tiltNorth(grid) {
  const height = grid.length;
  const width = grid[0].length;
  const newGrid = grid.map(row => [...row]);

  // Move rocks up
  for (let col = 0; col < width; col++) {
    let emptyRow = 0;
    for (let row = 0; row < height; row++) {
      if (newGrid[row][col] === 'O') {
        if (row !== emptyRow) {
          newGrid[emptyRow][col] = 'O';
          newGrid[row][col] = '.';
        }
        emptyRow++;
      } else if (newGrid[row][col] === '#') {
        emptyRow = row + 1;
      }
    }
  }
  return newGrid;
}

function tiltSouth(grid) {
  const height = grid.length;
  const width = grid[0].length;
  const newGrid = grid.map(row => [...row]);

  for (let col = 0; col < width; col++) {
    let emptyRow = height - 1;
    for (let row = height - 1; row >= 0; row--) {
      if (newGrid[row][col] === 'O') {
        if (row !== emptyRow) {
          newGrid[emptyRow][col] = 'O';
          newGrid[row][col] = '.';
        }
        emptyRow--;
      } else if (newGrid[row][col] === '#') {
        emptyRow = row - 1;
      }
    }
  }
  return newGrid;
}

function tiltWest(grid) {
  const height = grid.length;
  const width = grid[0].length;
  const newGrid = grid.map(row => [...row]);

  for (let row = 0; row < height; row++) {
    let emptyCol = 0;
    for (let col = 0; col < width; col++) {
      if (newGrid[row][col] === 'O') {
        if (col !== emptyCol) {
          newGrid[row][emptyCol] = 'O';
          newGrid[row][col] = '.';
        }
        emptyCol++;
      } else if (newGrid[row][col] === '#') {
        emptyCol = col + 1;
      }
    }
  }
  return newGrid;
}

function tiltEast(grid) {
  const height = grid.length;
  const width = grid[0].length;
  const newGrid = grid.map(row => [...row]);

  for (let row = 0; row < height; row++) {
    let emptyCol = width - 1;
    for (let col = width - 1; col >= 0; col--) {
      if (newGrid[row][col] === 'O') {
        if (col !== emptyCol) {
          newGrid[row][emptyCol] = 'O';
          newGrid[row][col] = '.';
        }
        emptyCol--;
      } else if (newGrid[row][col] === '#') {
        emptyCol = col - 1;
      }
    }
  }
  return newGrid;
}

function cycle(grid) {
  let currentGrid = grid;
  currentGrid = tiltNorth(currentGrid);
  currentGrid = tiltWest(currentGrid);
  currentGrid = tiltSouth(currentGrid);
  currentGrid = tiltEast(currentGrid);
  return currentGrid;
}

function getGridString(grid) {
  return grid.map(row => row.join('')).join('\n');
}

function calculateLoad(grid) {
  const height = grid.length;
  let total = 0;

  for (let row = 0; row < height; row++) {
    const rocks = grid[row].filter(cell => cell === 'O').length;
    total += rocks * (height - row);
  }

  return total;
}

export default function solution(input) {
  if (!input) return 0;

  let grid = input.split('\n').map(line => line.split(''));
  const targetCycles = 1000000000;
  const seen = new Map();
  let cycleCount = 0;

  while (cycleCount < targetCycles) {
    const gridString = getGridString(grid);
    
    if (seen.has(gridString)) {
      const cycleLength = cycleCount - seen.get(gridString);
      const remainingCycles = (targetCycles - cycleCount) % cycleLength;
      
      // Fast forward to the last few cycles
      for (let i = 0; i < remainingCycles; i++) {
        grid = cycle(grid);
      }
      break;
    }

    seen.set(gridString, cycleCount);
    grid = cycle(grid);
    cycleCount++;
  }

  return calculateLoad(grid);
}