I've implemented a solution for both parts of the Cosmic Expansion puzzle. Let me explain the approach:

1. First, I created a test file that verifies:
   - Part 1 with the example input (expansion factor of 2)
   - Part 2 with the example cases (expansion factors of 10 and 100)

2. The solution works as follows:
   - Parse the input into a 2D grid
   - Find all empty rows and columns and store them in Sets
   - Find all galaxy positions and store their coordinates
   - For each pair of galaxies:
     - Calculate the base Manhattan distance between them
     - Count how many empty rows and columns are between them
     - Apply the expansion factor to the empty spaces
     - Add the expanded distance to the total

3. The key insight is that we don't need to actually expand the universe in memory. Instead, we can:
   - Track which rows and columns are empty
   - When calculating distances between galaxies, count how many empty rows/columns are between them
   - Multiply those empty spaces by (expansionFactor - 1) to account for the expansion

4. The solution handles both parts with the same code, just using different expansion factors:
   - Part 1: expansionFactor = 2
   - Part 2: expansionFactor = 1,000,000

The solution is efficient because:
- We avoid creating huge grids in memory
- We only process each galaxy pair once
- We use Sets for quick lookup of empty rows/columns
- The Manhattan distance calculation is straightforward

The solve.js file runs both parts and saves the results to the output file. The code is clean, handles edge cases, and follows ES6 module style.