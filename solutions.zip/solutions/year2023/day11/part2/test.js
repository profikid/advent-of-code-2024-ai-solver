import solution from './solution.js';

describe('Day 11: Cosmic Expansion', () => {
  const example = `...#......
.......#..
#.........
..........
......#...
.#........
.........#
..........
.......#..
#...#.....`;

  test('Part 1 - Sum of shortest paths between galaxies with expansion factor 2', () => {
    expect(solution(example, 2)).toBe(374);
  });

  test('Part 2 - Examples with different expansion factors', () => {
    expect(solution(example, 10)).toBe(1030);
    expect(solution(example, 100)).toBe(8410);
  });
});