import fs from 'fs';
import solution from './solution.js';

const input = fs.readFileSync('input.txt', 'utf-8').trim();

// Part 1: expansion factor of 2
const result1 = solution(input, 2);
// Part 2: expansion factor of 1,000,000
const result2 = solution(input, 1000000);

const output = `Part 1: ${result1}\nPart 2: ${result2}`;
fs.writeFileSync('output.txt', output);