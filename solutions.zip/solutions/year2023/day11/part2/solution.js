export default function solution(input, expansionFactor = 2) {
  // Parse input into grid
  const grid = input.split('\n').map(line => line.split(''));
  
  // Find empty rows and columns
  const emptyRows = new Set();
  const emptyCols = new Set();
  
  // Find empty rows
  for (let y = 0; y < grid.length; y++) {
    if (grid[y].every(cell => cell === '.')) {
      emptyRows.add(y);
    }
  }
  
  // Find empty columns
  for (let x = 0; x < grid[0].length; x++) {
    if (grid.every(row => row[x] === '.')) {
      emptyCols.add(x);
    }
  }
  
  // Find all galaxies
  const galaxies = [];
  for (let y = 0; y < grid.length; y++) {
    for (let x = 0; x < grid[y].length; x++) {
      if (grid[y][x] === '#') {
        galaxies.push([y, x]);
      }
    }
  }
  
  let totalDistance = 0;
  
  // Calculate shortest path between each pair of galaxies
  for (let i = 0; i < galaxies.length; i++) {
    for (let j = i + 1; j < galaxies.length; j++) {
      const [y1, x1] = galaxies[i];
      const [y2, x2] = galaxies[j];
      
      // Count expanded rows between galaxies
      const expandedRows = Array.from(emptyRows).filter(row => 
        (row > Math.min(y1, y2) && row < Math.max(y1, y2))
      ).length;
      
      // Count expanded columns between galaxies
      const expandedCols = Array.from(emptyCols).filter(col => 
        (col > Math.min(x1, x2) && col < Math.max(x1, x2))
      ).length;
      
      // Calculate Manhattan distance with expansion factor
      const baseDistance = Math.abs(y2 - y1) + Math.abs(x2 - x1);
      const expansion = (expandedRows + expandedCols) * (expansionFactor - 1);
      totalDistance += baseDistance + expansion;
    }
  }
  
  return totalDistance;
}