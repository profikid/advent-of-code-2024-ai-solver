I've implemented the solution for Day 11 Part 1. Let me explain the approach:

1. First, I wrote test cases that cover:
   - The main example from the puzzle with expected output of 374
   - Edge cases like empty input and single galaxy
   - Basic validation of the puzzle requirements

2. The solution follows these steps:
   - Parse the input into a 2D grid
   - Find empty rows and columns that need expansion
   - Find all galaxy positions in the grid
   - For each pair of galaxies:
     - Calculate Manhattan distance between them
     - Add extra distance for each empty row/column between them
     - Sum up all distances

3. Key points in the implementation:
   - Handles edge cases (empty input, single galaxy)
   - Uses efficient Manhattan distance calculation
   - Accounts for cosmic expansion by counting empty rows/columns between each pair
   - Only counts each pair once as specified
   - Uses array methods to track empty rows and columns

4. The solve.js file:
   - Reads the input
   - Runs the solution
   - Writes the result to output.txt

The code has passed all tests and should work correctly with the actual input. Would you like me to explain any part in more detail or proceed with Part 2 of the puzzle?