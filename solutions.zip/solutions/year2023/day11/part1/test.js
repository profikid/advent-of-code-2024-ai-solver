import solution from './solution.js';

describe('Day 11: Cosmic Expansion - Part 1', () => {
    const input = `...#......
.......#..
#.........
..........
......#...
.#........
.........#
..........
.......#..
#...#.....`;

    test('should find sum of shortest paths between all galaxy pairs after expansion', () => {
        expect(solution(input)).toBe(374);
    });

    test('should handle empty input', () => {
        expect(solution('')).toBe(0);
    });

    test('should handle single galaxy', () => {
        expect(solution('#')).toBe(0);
    });
});