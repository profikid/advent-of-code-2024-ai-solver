export default function solution(input) {
    if (!input || input.length === 0) return 0;
    
    // Parse input into grid
    let grid = input.split('\n').map(line => line.split(''));
    
    // Find empty rows and columns
    const emptyRows = [];
    const emptyCols = [];
    
    // Find empty rows
    for (let i = 0; i < grid.length; i++) {
        if (grid[i].every(cell => cell === '.')) {
            emptyRows.push(i);
        }
    }
    
    // Find empty columns
    for (let j = 0; j < grid[0].length; j++) {
        let isEmpty = true;
        for (let i = 0; i < grid.length; i++) {
            if (grid[i][j] === '#') {
                isEmpty = false;
                break;
            }
        }
        if (isEmpty) {
            emptyCols.push(j);
        }
    }
    
    // Find galaxy positions
    const galaxies = [];
    for (let i = 0; i < grid.length; i++) {
        for (let j = 0; j < grid[i].length; j++) {
            if (grid[i][j] === '#') {
                galaxies.push([i, j]);
            }
        }
    }
    
    if (galaxies.length <= 1) return 0;
    
    // Calculate shortest paths between all pairs
    let totalDistance = 0;
    for (let i = 0; i < galaxies.length - 1; i++) {
        for (let j = i + 1; j < galaxies.length; j++) {
            const [row1, col1] = galaxies[i];
            const [row2, col2] = galaxies[j];
            
            // Count expanded rows and columns between galaxies
            const expandedRows = emptyRows.filter(row => 
                (row > Math.min(row1, row2) && row < Math.max(row1, row2))
            ).length;
            
            const expandedCols = emptyCols.filter(col => 
                (col > Math.min(col1, col2) && col < Math.max(col1, col2))
            ).length;
            
            // Calculate Manhattan distance with expansion
            const baseDistance = Math.abs(row2 - row1) + Math.abs(col2 - col1);
            const expandedDistance = baseDistance + expandedRows + expandedCols;
            
            totalDistance += expandedDistance;
        }
    }
    
    return totalDistance;
}