// Function to build adjacency list from input
function buildGraph(input) {
  const graph = new Map();
  
  input.split('\n').forEach(line => {
    const [source, targets] = line.split(': ');
    const connections = targets.split(' ');
    
    // Initialize source if not exists
    if (!graph.has(source)) {
      graph.set(source, new Set());
    }
    
    // Add bidirectional connections
    connections.forEach(target => {
      if (!graph.has(target)) {
        graph.set(target, new Set());
      }
      graph.get(source).add(target);
      graph.get(target).add(source);
    });
  });
  
  return graph;
}

// Function to count reachable nodes from a start node
function countConnectedNodes(graph, start, excluded) {
  const visited = new Set();
  const queue = [start];
  visited.add(start);
  
  while (queue.length > 0) {
    const current = queue.shift();
    for (const neighbor of graph.get(current)) {
      const edge = [current, neighbor].sort().join(',');
      if (!visited.has(neighbor) && !excluded.has(edge)) {
        visited.add(neighbor);
        queue.push(neighbor);
      }
    }
  }
  
  return visited.size;
}

// Function to find edge frequency using BFS
function getEdgeFrequencies(graph) {
  const frequencies = new Map();
  
  for (const [start] of graph) {
    const visited = new Set();
    const queue = [[start, null]];
    
    while (queue.length > 0) {
      const [current, parent] = queue.shift();
      if (visited.has(current)) continue;
      visited.add(current);
      
      if (parent !== null) {
        const edge = [parent, current].sort().join(',');
        frequencies.set(edge, (frequencies.get(edge) || 0) + 1);
      }
      
      for (const neighbor of graph.get(current)) {
        if (!visited.has(neighbor)) {
          queue.push([neighbor, current]);
        }
      }
    }
  }
  
  return frequencies;
}

export default function solution(input) {
  const graph = buildGraph(input);
  
  // Get edge frequencies to identify potential bridges
  const frequencies = getEdgeFrequencies(graph);
  const sortedEdges = [...frequencies.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([edge]) => edge);
  
  // Try different combinations of three edges
  for (let i = 0; i < sortedEdges.length - 2; i++) {
    for (let j = i + 1; j < sortedEdges.length - 1; j++) {
      for (let k = j + 1; k < sortedEdges.length; k++) {
        const excluded = new Set([sortedEdges[i], sortedEdges[j], sortedEdges[k]]);
        
        // Count size of first group
        const firstNode = graph.keys().next().value;
        const group1Size = countConnectedNodes(graph, firstNode, excluded);
        const totalSize = graph.size;
        const group2Size = totalSize - group1Size;
        
        // If we found two groups, return their product
        if (group1Size + group2Size === totalSize && group1Size > 0 && group2Size > 0) {
          return group1Size * group2Size;
        }
      }
    }
  }
  
  return 0;
}