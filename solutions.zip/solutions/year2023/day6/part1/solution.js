export default function solution(input) {
    // Parse input
    const [timeLine, distanceLine] = input.split('\n');
    const times = timeLine.split(':')[1].trim().split(/\s+/).map(Number);
    const distances = distanceLine.split(':')[1].trim().split(/\s+/).map(Number);

    // Calculate ways to win for each race
    const waysToWin = times.map((time, index) => {
        const recordDistance = distances[index];
        let winningWays = 0;

        // For each possible hold time
        for (let holdTime = 0; holdTime <= time; holdTime++) {
            const speed = holdTime; // Speed is equal to hold time
            const remainingTime = time - holdTime;
            const distance = speed * remainingTime;

            if (distance > recordDistance) {
                winningWays++;
            }
        }
        return winningWays;
    });

    // Multiply all ways together
    return waysToWin.reduce((acc, curr) => acc * curr, 1);
}