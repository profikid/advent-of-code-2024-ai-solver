import solution from './solution.js';

describe('Day 6: Wait For It - Part 1', () => {
    const example = `Time:      7  15   30
Distance:  9  40  200`;

    test('should find number of ways to beat the record multiplied together', () => {
        expect(solution(example)).toBe(288);
    });

    test('should handle single race correctly', () => {
        expect(solution(`Time:      7
Distance:  9`)).toBe(4);
    });

    test('should parse input correctly', () => {
        const result = solution(`Time:      7  15
Distance:  9  40`);
        expect(result).toBe(32); // 4 * 8
    });
});