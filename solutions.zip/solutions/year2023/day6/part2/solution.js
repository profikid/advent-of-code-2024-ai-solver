export default function solution(input) {
    // Parse input removing spaces between numbers
    const [timeLine, distanceLine] = input.split('\n');
    const time = parseInt(timeLine.replace(/[^0-9]/g, ''));
    const distance = parseInt(distanceLine.replace(/[^0-9]/g, ''));

    // For each hold time, calculate distance traveled and check if it beats record
    let waysToWin = 0;
    
    // Since this is a quadratic equation: 
    // distance = holdTime * (time - holdTime)
    // we can solve it using quadratic formula to find the roots
    // holdTime^2 - time*holdTime + distance = 0
    const a = 1;
    const b = -time;
    const c = distance;
    
    // Using quadratic formula (-b ± √(b^2 - 4ac)) / 2a
    const discriminant = Math.sqrt(b * b - 4 * a * c);
    const root1 = (-b - discriminant) / (2 * a);
    const root2 = (-b + discriminant) / (2 * a);
    
    // Round up the lower bound and round down the upper bound
    // Add 1 to convert from exclusive to inclusive bounds
    const lowerBound = Math.ceil(Math.min(root1, root2));
    const upperBound = Math.floor(Math.max(root1, root2));
    
    waysToWin = upperBound - lowerBound + 1;

    return waysToWin;
}