import solution from './solution.js';

describe('day 6 part 2', () => {
  it('should calculate number of ways to win when considering single long race', () => {
    const input = `Time:      7  15   30
Distance:  9  40  200`;
    
    expect(solution(input)).toBe(71503);
  });
});