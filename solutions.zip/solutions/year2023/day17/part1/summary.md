I've implemented a solution for Day 17 Part 1. Let me explain the approach:

1. First, I created test cases based on the example given in the puzzle, expecting a heat loss of 102 for the sample input. I also added a test for invalid input.

2. The solution uses Dijkstra's algorithm with a priority queue to find the path with minimum heat loss while respecting the constraints:
   - Can't move more than three blocks in the same direction
   - Can't reverse direction
   - Must turn 90 degrees left or right after three blocks

3. The solution includes:
   - A PriorityQueue class for efficient path finding
   - Four possible directions (right, down, left, up)
   - State tracking that includes position, direction, and consecutive steps
   - Bounds checking and validation
   - Heat loss accumulation

4. The algorithm:
   - Starts from the top-left corner
   - At each step, considers all valid moves (respecting the three-block limit and direction constraints)
   - Uses a priority queue to always explore the path with minimum heat loss first
   - Keeps track of visited states to avoid cycles
   - Returns the minimum heat loss when reaching the bottom-right corner

5. The solve script reads the input file, runs the solution, and saves the result to the output file.

The solution follows the puzzle requirements:
- Starts from the top-left corner
- Ends at the bottom-right corner
- Never moves more than three blocks in the same direction
- Can only turn left or right (no reversing)
- Calculates the minimum possible heat loss

The code is careful to handle edge cases:
- Empty input
- Grid boundaries
- Invalid moves
- Direction constraints

The test passes with the example input, and the solve script should work with the actual puzzle input.