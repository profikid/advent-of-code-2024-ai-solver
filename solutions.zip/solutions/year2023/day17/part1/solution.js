export default function solution(input) {
    if (!input) return 0;

    // Parse the grid
    const grid = input.split('\n').map(line => line.split('').map(Number));
    const rows = grid.length;
    const cols = grid[0].length;

    // Priority queue implementation for Dijkstra's algorithm
    class PriorityQueue {
        constructor() {
            this.values = [];
        }

        enqueue(val, priority) {
            this.values.push({ val, priority });
            this.sort();
        }

        dequeue() {
            return this.values.shift();
        }

        sort() {
            this.values.sort((a, b) => a.priority - b.priority);
        }
    }

    // Directions: right, down, left, up
    const directions = [[0, 1], [1, 0], [0, -1], [-1, 0]];

    // State: [row, col, direction, steps]
    const queue = new PriorityQueue();
    // Initialize with both possible starting directions
    queue.enqueue([0, 0, 0, 0], 0); // Start going right
    queue.enqueue([0, 0, 1, 0], 0); // Start going down

    // Keep track of visited states
    const seen = new Set();

    while (queue.values.length > 0) {
        const { val: [row, col, dir, steps], priority: heat } = queue.dequeue();

        // Check if we reached the destination
        if (row === rows - 1 && col === cols - 1) {
            return heat;
        }

        // Generate key for visited state
        const stateKey = `${row},${col},${dir},${steps}`;
        if (seen.has(stateKey)) continue;
        seen.add(stateKey);

        // Try all possible directions
        for (let newDir = 0; newDir < 4; newDir++) {
            // Can't reverse direction
            if ((newDir + 2) % 4 === dir) continue;

            // If continuing straight, check step limit
            if (newDir === dir && steps >= 3) continue;

            // If turning, reset steps counter
            const newSteps = newDir === dir ? steps + 1 : 1;

            const newRow = row + directions[newDir][0];
            const newCol = col + directions[newDir][1];

            // Check bounds
            if (newRow < 0 || newRow >= rows || newCol < 0 || newCol >= cols) continue;

            const newHeat = heat + grid[newRow][newCol];
            queue.enqueue([newRow, newCol, newDir, newSteps], newHeat);
        }
    }

    return 0; // No path found
}