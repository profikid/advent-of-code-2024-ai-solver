export default function solution(input) {
    const grid = input.split('\n').map(line => line.split('').map(Number));
    const height = grid.length;
    const width = grid[0].length;

    // Priority queue implementation
    class PriorityQueue {
        constructor() {
            this.values = [];
        }

        enqueue(element, priority) {
            this.values.push({ element, priority });
            this.sort();
        }

        dequeue() {
            return this.values.shift();
        }

        sort() {
            this.values.sort((a, b) => a.priority - b.priority);
        }
    }

    // Direction constants
    const DIRECTIONS = [
        [0, 1],  // right
        [1, 0],  // down
        [0, -1], // left
        [-1, 0]  // up
    ];

    // State key function
    const getStateKey = (row, col, direction, steps) => 
        `${row},${col},${direction},${steps}`;

    // Create visited set and priority queue
    const visited = new Set();
    const pq = new PriorityQueue();

    // Initialize with starting positions (can start by going right or down)
    pq.enqueue({ row: 0, col: 0, direction: 0, steps: 0, heat: 0 }, 0);
    pq.enqueue({ row: 0, col: 0, direction: 1, steps: 0, heat: 0 }, 0);

    while (pq.values.length > 0) {
        const current = pq.dequeue().element;
        const { row, col, direction, steps, heat } = current;

        // Check if we reached the end with minimum required steps
        if (row === height - 1 && col === width - 1 && steps >= 4) {
            return heat;
        }

        const stateKey = getStateKey(row, col, direction, steps);
        if (visited.has(stateKey)) continue;
        visited.add(stateKey);

        // Try all possible directions
        for (let newDirection = 0; newDirection < 4; newDirection++) {
            // Can't reverse direction
            if (Math.abs(newDirection - direction) === 2) continue;

            // Must go straight if haven't reached minimum distance
            if (steps < 4 && newDirection !== direction && !(row === 0 && col === 0)) continue;

            // Can't make a turn after 10 steps
            if (steps === 10 && newDirection === direction) continue;

            // Reset steps if turning, increment if going straight
            const newSteps = newDirection === direction ? steps + 1 : 1;

            if (newSteps > 10) continue;

            const [dr, dc] = DIRECTIONS[newDirection];
            const newRow = row + dr;
            const newCol = col + dc;

            // Check bounds
            if (newRow < 0 || newRow >= height || newCol < 0 || newCol >= width) continue;

            const newHeat = heat + grid[newRow][newCol];
            pq.enqueue({
                row: newRow,
                col: newCol,
                direction: newDirection,
                steps: newSteps,
                heat: newHeat
            }, newHeat);
        }
    }

    return -1; // No path found
}