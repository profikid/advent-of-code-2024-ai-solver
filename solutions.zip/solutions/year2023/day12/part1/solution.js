function isValidArrangement(springs, groups) {
    const damagedGroups = springs
        .split('.')
        .filter(group => group.length > 0)
        .map(group => group.length);
    
    if (damagedGroups.length !== groups.length) return false;
    
    for (let i = 0; i < groups.length; i++) {
        if (damagedGroups[i] !== groups[i]) return false;
    }
    
    return true;
}

function generatePossibleArrangements(pattern, index = 0, current = '') {
    if (index === pattern.length) {
        return [current];
    }

    if (pattern[index] === '?') {
        return [
            ...generatePossibleArrangements(pattern, index + 1, current + '.'),
            ...generatePossibleArrangements(pattern, index + 1, current + '#')
        ];
    }
    
    return generatePossibleArrangements(pattern, index + 1, current + pattern[index]);
}

export default function solution(input) {
    const lines = input.trim().split('\n');
    let totalArrangements = 0;

    for (const line of lines) {
        const [springs, groupsStr] = line.split(' ');
        const groups = groupsStr.split(',').map(Number);
        
        const arrangements = generatePossibleArrangements(springs);
        const validArrangements = arrangements.filter(arr => isValidArrangement(arr, groups));
        
        totalArrangements += validArrangements.length;
    }

    return totalArrangements;
}