import solution from './solution.js';

describe('day 12 part 1', () => {
    it('should verify the arrangement counts for given row samples', () => {
        const input = `???.### 1,1,3
.??..??...?##. 1,1,3
?#?#?#?#?#?#?#? 1,3,1,6
????.#...#... 4,1,1
????.######..#####. 1,6,5
?###???????? 3,2,1`;

        const result = solution(input);
        expect(result).toBe(21);
    });

    // Individual test cases to help debug
    it('should handle single line cases', () => {
        expect(solution('???.### 1,1,3')).toBe(1);
        expect(solution('.??..??...?##. 1,1,3')).toBe(4);
        expect(solution('?###???????? 3,2,1')).toBe(10);
    });
});