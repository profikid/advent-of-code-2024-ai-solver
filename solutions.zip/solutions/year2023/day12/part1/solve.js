import fs from 'fs';
import solution from './solution.js';

const input = fs.readFileSync('input.txt', 'utf-8');
const result = solution(input);

fs.writeFileSync('output.txt', result.toString());