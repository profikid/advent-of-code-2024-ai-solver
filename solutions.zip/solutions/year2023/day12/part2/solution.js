function memoizedArrangements(pattern, numbers, patternIndex = 0, numbersIndex = 0, currentGroup = 0, memo = new Map()) {
    const key = `${patternIndex},${numbersIndex},${currentGroup}`;
    if (memo.has(key)) return memo.get(key);

    // Base case: reached end of pattern
    if (patternIndex === pattern.length) {
        // Valid if we've used all numbers and aren't in the middle of a group
        if (numbersIndex === numbers.length && currentGroup === 0) return 1;
        // Or if we're at the last number and it matches our current group
        if (numbersIndex === numbers.length - 1 && numbers[numbersIndex] === currentGroup) return 1;
        return 0;
    }

    let result = 0;
    const possibleChars = pattern[patternIndex] === '?' ? ['.', '#'] : [pattern[patternIndex]];

    for (const char of possibleChars) {
        if (char === '#') {
            // Continue current group
            result += memoizedArrangements(pattern, numbers, patternIndex + 1, numbersIndex, currentGroup + 1, memo);
        } else { // char === '.'
            if (currentGroup === 0) {
                // No group in progress, just move forward
                result += memoizedArrangements(pattern, numbers, patternIndex + 1, numbersIndex, 0, memo);
            } else if (numbersIndex < numbers.length && numbers[numbersIndex] === currentGroup) {
                // End current group if it matches the expected size
                result += memoizedArrangements(pattern, numbers, patternIndex + 1, numbersIndex + 1, 0, memo);
            }
        }
    }

    memo.set(key, result);
    return result;
}

export default function solution(input) {
    const lines = input.trim().split('\n');
    let total = 0;

    for (const line of lines) {
        const [pattern, numbersStr] = line.split(' ');
        const numbers = numbersStr.split(',').map(Number);

        // Create unfolded pattern and numbers
        const unfoldedPattern = Array(5).fill(pattern).join('?');
        const unfoldedNumbers = Array(5).fill(numbers).flat();

        // Calculate arrangements for unfolded pattern
        const arrangements = memoizedArrangements(unfoldedPattern, unfoldedNumbers);
        total += arrangements;
    }

    return total;
}