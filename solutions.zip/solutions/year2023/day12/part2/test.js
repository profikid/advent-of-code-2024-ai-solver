import solution from './solution.js';

describe('Day 12, Part 2', () => {
    test('unfolds records and counts possible arrangements', () => {
        const input = `???.### 1,1,3
.??..??...?##. 1,1,3
?#?#?#?#?#?#?#? 1,3,1,6
????.#...#... 4,1,1
????.######..#####. 1,6,5
?###???????? 3,2,1`;

        const result = solution(input);
        expect(result).toBe(525152);
    });

    test('simple unfolded cases', () => {
        expect(solution('.# 1')).toBe(1); // .#?.#?.#?.#?.# 1,1,1,1,1
        expect(solution('???.### 1,1,3')).toBe(1);
    });
});