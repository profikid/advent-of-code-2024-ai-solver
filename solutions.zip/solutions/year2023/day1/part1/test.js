import solution from './solution.js';

describe('Day 1: Trebuchet?! Part 1', () => {
    it('should find calibration value by combining first and last digit of each line', () => {
        const input = `1abc2
pqr3stu8vwx
a1b2c3d4e5f
treb7uchet`;
        
        expect(solution(input)).toBe(142);
    });

    it('should handle single digit in line', () => {
        const input = `treb7uchet`;
        expect(solution(input)).toBe(77);
    });

    it('should handle empty input', () => {
        expect(solution('')).toBe(0);
    });
});