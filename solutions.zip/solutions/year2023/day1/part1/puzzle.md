\--- Day 1: Trebuchet?! ---
---------------------------

Something is wrong with global snow production, and you've been selected to take a look. The Elves have even given you a map; on it, they've used stars to mark the top fifty locations that are likely to be having problems.

You've been doing this long enough to know that to restore snow operations, you need to check all _fifty stars_ by December 25th.

Collect stars by solving puzzles. Two puzzles will be made available on each day in the Advent calendar; the second puzzle is unlocked when you complete the first. Each puzzle grants _one star_. Good luck!

You try to ask why they can't just use a [weather machine](/2015/day/1) ("not powerful enough") and where they're even sending you ("the sky") and why your map looks mostly blank ("you sure ask a lot of questions") and hang on did you just say the sky ("of course, where do you think snow comes from") when you realize that the Elves are already loading you into a [trebuchet](https://en.wikipedia.org/wiki/Trebuchet) ("please hold still, we need to strap you in").

As they're making the final adjustments, they discover that their calibration document (your puzzle input) has been _amended_ by a very young Elf who was apparently just excited to show off her art skills. Consequently, the Elves are having trouble reading the values on the document.

The newly-improved calibration document consists of lines of text; each line originally contained a specific _calibration value_ that the Elves now need to recover. On each line, the calibration value can be found by combining the _first digit_ and the _last digit_ (in that order) to form a single _two-digit number_.

For example:

    1abc2
    pqr3stu8vwx
    a1b2c3d4e5f
    treb7uchet
    

In this example, the calibration values of these four lines are `12`, `38`, `15`, and `77`. Adding these together produces `_142_`.

Consider your entire calibration document. _What is the sum of all of the calibration values?_

To begin, [get your puzzle input](1/input).

Answer:  

You can also \[Shareon [Bluesky](https://bsky.app/intent/compose?text=%22Trebuchet%3F%21%22+%2D+Day+1+%2D+Advent+of+Code+2023+%23AdventOfCode+https%3A%2F%2Fadventofcode%2Ecom%2F2023%2Fday%2F1) [Twitter](https://twitter.com/intent/tweet?text=%22Trebuchet%3F%21%22+%2D+Day+1+%2D+Advent+of+Code+2023&url=https%3A%2F%2Fadventofcode%2Ecom%2F2023%2Fday%2F1&related=ericwastl&hashtags=AdventOfCode) [Mastodon](javascript:void\(0\);)\] this puzzle.