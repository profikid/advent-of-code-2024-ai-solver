export default function solution(input) {
    if (!input) return 0;
    
    // Split input into lines
    const lines = input.trim().split('\n');
    
    // Process each line
    return lines.reduce((sum, line) => {
        // Extract all digits from the line
        const digits = line.match(/\d/g);
        
        if (!digits || digits.length === 0) return sum;
        
        // Get first and last digit
        const firstDigit = digits[0];
        const lastDigit = digits[digits.length - 1];
        
        // Combine digits and convert to number
        const calibrationValue = parseInt(firstDigit + lastDigit);
        
        return sum + calibrationValue;
    }, 0);
}