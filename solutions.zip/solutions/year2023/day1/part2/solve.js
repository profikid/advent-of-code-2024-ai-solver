import fs from 'fs';
import solution from './solution.js';

// Part 1
const input = fs.readFileSync('./input.txt', 'utf-8');
const result1 = solution(input);
console.log('Part 1:', result1);

// Part 2
const result2 = solution(input, true);
console.log('Part 2:', result2);

fs.writeFileSync('./output.txt', `Part 1: ${result1}\nPart 2: ${result2}`);