const numberWords = {
  'one': '1',
  'two': '2',
  'three': '3',
  'four': '4',
  'five': '5',
  'six': '6',
  'seven': '7',
  'eight': '8',
  'nine': '9'
};

function findFirstAndLastDigit(line, includeWords = false) {
  let firstDigit = null;
  let lastDigit = null;
  
  for (let i = 0; i < line.length; i++) {
    let digit = null;
    
    // Check for numeric digit
    if (/\d/.test(line[i])) {
      digit = line[i];
    }
    // Check for word numbers if includeWords is true
    else if (includeWords) {
      for (const [word, num] of Object.entries(numberWords)) {
        if (line.slice(i).startsWith(word)) {
          digit = num;
          break;
        }
      }
    }
    
    if (digit !== null) {
      if (firstDigit === null) {
        firstDigit = digit;
      }
      lastDigit = digit;
    }
  }
  
  return firstDigit && lastDigit ? parseInt(firstDigit + lastDigit) : 0;
}

export default function solution(input, part2 = false) {
  const lines = input.trim().split('\n');
  return lines.reduce((sum, line) => sum + findFirstAndLastDigit(line, part2), 0);
}