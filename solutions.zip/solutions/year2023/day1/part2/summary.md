I've created a complete solution for both parts of Day 1's puzzle. Let me explain the solution step by step:

1. First, I created a test file that covers both parts of the puzzle:
   - Part 1 tests the example with numeric digits only
   - Part 2 tests the example with both numeric and word-based numbers

2. The solution has the following components:
   - A map of number words to their digit equivalents
   - A `findFirstAndLastDigit` helper function that:
     - Scans each character of the line
     - Finds either numeric digits or word numbers (if part2 is true)
     - Keeps track of the first and last digits found
     - Combines them into a two-digit number
   - The main `solution` function that:
     - Splits input into lines
     - Processes each line using the helper function
     - Sums up all the calibration values

3. For Part 1:
   - We only look for numeric digits in the string
   - We combine the first and last digits found

4. For Part 2:
   - We also look for spelled-out numbers like "one", "two", etc.
   - We handle overlapping cases (like "oneight" should find both "one" and "eight")
   - We maintain the same logic of combining first and last digits

5. The solve script:
   - Reads the input file
   - Runs both parts of the solution
   - Writes the results to the output file

The solution handles edge cases like:
- Lines with no digits
- Overlapping number words
- Single digits (using it as both first and last)
- Empty lines
- Mixed numeric and word-based numbers

The test cases verify that the solution works correctly for both the simple and complex examples provided in the puzzle description.