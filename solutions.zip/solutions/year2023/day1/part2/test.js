import solution from './solution.js';

describe('Day 1: Trebuchet?!', () => {
  describe('Part 1', () => {
    it('should find calibration values and sum them', () => {
      const input = `1abc2
pqr3stu8vwx
a1b2c3d4e5f
treb7uchet`;
      expect(solution(input)).toBe(142);
    });
  });

  describe('Part 2', () => {
    it('should find calibration values including word numbers and sum them', () => {
      const input = `two1nine
eightwothree
abcone2threexyz
xtwone3four
4nineeightseven2
zoneight234
7pqrstsixteen`;
      expect(solution(input, true)).toBe(281);
    });
  });
});