import solution from './solution.js';

describe('Day 3: Gear Ratios - Part 1', () => {
    const example = `467..114..
...*......
..35..633.
......#...
617*......
.....+.58.
..592.....
......755.
...$.*....
.664.598..`;

    test('should sum all part numbers adjacent to symbols', () => {
        expect(solution(example)).toBe(4361);
    });

    test('should handle empty input', () => {
        expect(solution('')).toBe(0);
    });

    test('should handle input with no valid part numbers', () => {
        expect(solution('123\n...\n456')).toBe(0);
    });

    test('should handle input with all valid part numbers', () => {
        expect(solution('123\n.#.\n456')).toBe(579);
    });
});