export default function solution(input) {
    if (!input) return 0;
    
    // Convert input to 2D array
    const grid = input.split('\n').map(line => line.split(''));
    const rows = grid.length;
    const cols = grid[0].length;
    
    // Helper function to check if a character is a symbol
    const isSymbol = (char) => {
        return char !== '.' && isNaN(char);
    };
    
    // Helper function to check if position is adjacent to a symbol
    const isAdjacentToSymbol = (row, col) => {
        const directions = [
            [-1, -1], [-1, 0], [-1, 1],
            [0, -1],           [0, 1],
            [1, -1],  [1, 0],  [1, 1]
        ];
        
        for (const [dx, dy] of directions) {
            const newRow = row + dx;
            const newCol = col + dy;
            
            if (newRow >= 0 && newRow < rows && 
                newCol >= 0 && newCol < cols && 
                isSymbol(grid[newRow][newCol])) {
                return true;
            }
        }
        return false;
    };
    
    let sum = 0;
    
    // Iterate through each row
    for (let row = 0; row < rows; row++) {
        let currentNumber = '';
        let isPartNumber = false;
        
        // Iterate through each column
        for (let col = 0; col < cols; col++) {
            const char = grid[row][col];
            
            // If current character is a digit
            if (!isNaN(char)) {
                currentNumber += char;
                // Check if this digit is adjacent to a symbol
                if (!isPartNumber && isAdjacentToSymbol(row, col)) {
                    isPartNumber = true;
                }
            }
            
            // If we've reached the end of a number or the end of a line
            if (isNaN(char) || col === cols - 1) {
                if (currentNumber && isPartNumber) {
                    sum += parseInt(currentNumber);
                }
                currentNumber = '';
                isPartNumber = false;
            }
        }
    }
    
    return sum;
}