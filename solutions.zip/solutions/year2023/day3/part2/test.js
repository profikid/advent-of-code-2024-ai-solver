import solution from './solution.js';

describe('Day 3: Gear Ratios', () => {
  const input = `467..114..
...*......
..35..633.
......#...
617*......
.....+.58.
..592.....
......755.
...$.*....
.664.598..`;

  test('Part 1: Sum of all part numbers', () => {
    expect(solution(input).part1).toBe(4361);
  });

  test('Part 2: Sum of gear ratios', () => {
    expect(solution(input).part2).toBe(467835);
  });
});