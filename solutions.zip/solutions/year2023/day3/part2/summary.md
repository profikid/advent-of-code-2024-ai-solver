I've created a complete solution for both parts of Day 3's puzzle. Let me explain the approach:

1. First, I created a test file that checks both parts using the example provided in the puzzle description.

2. The solution handles both parts in a single function that returns an object with both answers. Here's how it works:

For Part 1:
- Scans through each line looking for numbers
- For each number found, checks all adjacent positions (including diagonals) for symbols
- If a symbol is found adjacent to a number, adds that number to part1Sum
- Carefully handles edge cases by checking bounds

For Part 2:
- Looks specifically for '*' characters that could be gears
- For each '*', finds all adjacent numbers (using a helper function)
- If exactly two numbers are adjacent to a '*', multiplies them together and adds to part2Sum
- Uses a Set to avoid counting the same number twice
- Handles edge cases and boundary conditions

The solution includes several helper functions:
- isSymbol: checks if a character is a symbol (not a dot or number)
- hasAdjacentSymbol: checks if a number has any adjacent symbols
- getAdjacentNumbers: finds all numbers adjacent to a potential gear

3. The solve script reads the input file and writes both answers to the output file.

The code is written defensively with:
- Bounds checking to prevent array index out of bounds
- Proper handling of edge cases (numbers at edges of the schematic)
- Deduplication of numbers in part 2
- Clean separation of concerns between different functions

The tests pass for both the example cases:
- Part 1: 4361
- Part 2: 467835

And the solution successfully processes the actual input file.