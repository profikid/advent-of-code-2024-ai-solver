export default function solution(input) {
  const lines = input.split('\n');
  const height = lines.length;
  const width = lines[0].length;

  // Helper function to check if a character is a symbol
  const isSymbol = (char) => char !== '.' && isNaN(char);

  // Helper function to check if a position has an adjacent symbol
  const hasAdjacentSymbol = (row, start, end) => {
    for (let r = Math.max(0, row - 1); r <= Math.min(height - 1, row + 1); r++) {
      for (let c = Math.max(0, start - 1); c <= Math.min(width - 1, end); c++) {
        if (isSymbol(lines[r][c])) {
          return true;
        }
      }
    }
    return false;
  };

  // Helper function to get adjacent numbers to a gear
  const getAdjacentNumbers = (gearRow, gearCol) => {
    const numbers = [];
    const seen = new Set(); // To avoid counting the same number twice

    for (let r = Math.max(0, gearRow - 1); r <= Math.min(height - 1, gearRow + 1); r++) {
      let numStart = -1;
      let num = '';

      for (let c = 0; c <= width; c++) {
        if (c < width && !isNaN(lines[r][c])) {
          if (numStart === -1) numStart = c;
          num += lines[r][c];
        } else if (numStart !== -1) {
          // We've found a complete number
          const key = `${r},${numStart}`; // Create a unique key for this number
          if (!seen.has(key) && 
              Math.max(numStart - 1, 0) <= gearCol && 
              gearCol <= Math.min(c, width - 1)) {
            numbers.push(parseInt(num));
            seen.add(key);
          }
          numStart = -1;
          num = '';
        }
      }
    }
    return numbers;
  };

  let part1Sum = 0;
  let part2Sum = 0;

  // Process each line to find part numbers and gears
  for (let row = 0; row < height; row++) {
    let numStart = -1;
    let num = '';

    for (let col = 0; col <= width; col++) {
      if (col < width && !isNaN(lines[row][col])) {
        if (numStart === -1) numStart = col;
        num += lines[row][col];
      } else if (numStart !== -1) {
        // We've found a complete number
        if (hasAdjacentSymbol(row, numStart, col)) {
          part1Sum += parseInt(num);
        }
        numStart = -1;
        num = '';
      }
    }
  }

  // Find gears and calculate gear ratios
  for (let row = 0; row < height; row++) {
    for (let col = 0; col < width; col++) {
      if (lines[row][col] === '*') {
        const adjacentNumbers = getAdjacentNumbers(row, col);
        if (adjacentNumbers.length === 2) {
          part2Sum += adjacentNumbers[0] * adjacentNumbers[1];
        }
      }
    }
  }

  return {
    part1: part1Sum,
    part2: part2Sum
  };
}