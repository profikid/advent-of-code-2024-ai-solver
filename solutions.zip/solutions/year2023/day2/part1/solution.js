export default function solution(input) {
  const MAX_RED = 12;
  const MAX_GREEN = 13;
  const MAX_BLUE = 14;

  const games = input.trim().split('\n');
  let sumPossibleIds = 0;

  for (const game of games) {
    // Extract game ID and sets
    const [gameInfo, setsInfo] = game.split(': ');
    const gameId = parseInt(gameInfo.split(' ')[1]);
    const sets = setsInfo.split('; ');
    
    let isPossible = true;
    
    // Check each set in the game
    for (const set of sets) {
      const cubes = set.split(', ');
      let red = 0, green = 0, blue = 0;
      
      // Count cubes of each color in this set
      for (const cube of cubes) {
        const [count, color] = cube.split(' ');
        switch (color) {
          case 'red':
            red = parseInt(count);
            break;
          case 'green':
            green = parseInt(count);
            break;
          case 'blue':
            blue = parseInt(count);
            break;
        }
      }
      
      // Check if this set is possible
      if (red > MAX_RED || green > MAX_GREEN || blue > MAX_BLUE) {
        isPossible = false;
        break;
      }
    }
    
    if (isPossible) {
      sumPossibleIds += gameId;
    }
  }
  
  return sumPossibleIds;
}