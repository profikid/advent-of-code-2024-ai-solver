export default function solution(input) {
  const games = input.trim().split('\n').map(line => {
    const [gameId, sets] = line.split(': ');
    const id = parseInt(gameId.split(' ')[1]);
    const rounds = sets.split('; ').map(set => {
      const cubes = { red: 0, green: 0, blue: 0 };
      set.split(', ').forEach(cube => {
        const [count, color] = cube.split(' ');
        cubes[color] = parseInt(count);
      });
      return cubes;
    });
    return { id, rounds };
  });

  // Part 1: Find possible games with given cube limits
  const limits = { red: 12, green: 13, blue: 14 };
  const possibleGames = games.filter(game => 
    game.rounds.every(round =>
      round.red <= limits.red &&
      round.green <= limits.green &&
      round.blue <= limits.blue
    )
  );
  const part1 = possibleGames.reduce((sum, game) => sum + game.id, 0);

  // Part 2: Calculate power of minimum required cubes
  const minimumSets = games.map(game => {
    const minCubes = {
      red: Math.max(...game.rounds.map(r => r.red)),
      green: Math.max(...game.rounds.map(r => r.green)),
      blue: Math.max(...game.rounds.map(r => r.blue))
    };
    return minCubes.red * minCubes.green * minCubes.blue;
  });
  const part2 = minimumSets.reduce((sum, power) => sum + power, 0);

  return { part1, part2 };
}