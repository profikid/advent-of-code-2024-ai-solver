import solution from './solution.js';

describe('Day 20: Pulse Propagation (Part 2)', () => {
  test('Finding fewest button presses for rx module to receive low pulse', () => {
    // Basic test case with rx module
    const input = `broadcaster -> a
%a -> inv, con
&inv -> b
%b -> con
&con -> rx`;

    // This is a simplified test case 
    // In real scenario, rx needs to receive a low pulse
    // The actual test value would be much higher, but for
    // testing purposes we use a smaller number
    expect(solution(input)).toBeGreaterThan(0);
  });
});