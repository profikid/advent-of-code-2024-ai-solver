// Helper functions
function gcd(a, b) {
    while (b) {
        [a, b] = [b, a % b];
    }
    return a;
}

function lcm(a, b) {
    return (a * b) / gcd(a, b);
}

function lcmArray(arr) {
    return arr.reduce((a, b) => lcm(a, b));
}

export default function solution(input) {
    const modules = new Map();
    const conjunctionInputs = new Map();

    // Parse input and setup modules
    input.split('\n').forEach(line => {
        if (!line.trim()) return;
        const [source, destinations] = line.split(' -> ');
        const destList = destinations.split(', ');
        
        if (source === 'broadcaster') {
            modules.set('broadcaster', { type: 'broadcaster', destinations: destList });
        } else {
            const type = source[0];
            const name = source.slice(1);
            modules.set(name, {
                type,
                destinations: destList,
                state: type === '%' ? false : new Map()  // false for flip-flop, Map for conjunction
            });
        }
    });

    // Setup conjunction module inputs
    modules.forEach((module, name) => {
        module.destinations.forEach(dest => {
            if (modules.has(dest) && modules.get(dest).type === '&') {
                if (!conjunctionInputs.has(dest)) {
                    conjunctionInputs.set(dest, new Set());
                }
                conjunctionInputs.get(dest).add(name);
            }
        });
    });

    // Initialize conjunction modules memory
    conjunctionInputs.forEach((inputs, name) => {
        const memory = new Map();
        inputs.forEach(input => memory.set(input, false));
        modules.get(name).state = memory;
    });

    // Find modules that feed into rx
    let rxInput = '';
    modules.forEach((module, name) => {
        if (module.destinations.includes('rx')) {
            rxInput = name;
        }
    });

    // If rx is not found or not fed by a conjunction, return 0
    if (!rxInput || modules.get(rxInput).type !== '&') {
        return 0;
    }

    // Find the cycles of each input to the conjunction that feeds rx
    const cycles = [];
    const inputsToWatch = Array.from(modules.get(rxInput).state.keys());
    const cycleStates = new Map(inputsToWatch.map(input => [input, false]));
    
    let buttonPresses = 0;
    
    while (cycles.length < inputsToWatch.length) {
        buttonPresses++;
        const queue = [['broadcaster', false, 'button']];

        while (queue.length > 0) {
            const [currentName, pulse, source] = queue.shift();
            const module = modules.get(currentName);

            if (!module) continue;

            if (currentName === rxInput) {
                inputsToWatch.forEach(input => {
                    if (module.state.get(input) && !cycleStates.get(input)) {
                        cycleStates.set(input, true);
                        cycles.push(buttonPresses);
                    }
                });
            }

            let sendPulse = pulse;
            if (module.type === '%') {
                if (pulse) continue;
                module.state = !module.state;
                sendPulse = module.state;
            } else if (module.type === '&') {
                module.state.set(source, pulse);
                sendPulse = !Array.from(module.state.values()).every(v => v);
            }

            for (const dest of module.destinations) {
                queue.push([dest, sendPulse, currentName]);
            }
        }
    }

    // Calculate least common multiple of all cycles
    return lcmArray(cycles);
}