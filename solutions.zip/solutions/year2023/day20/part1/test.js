import solution from './solution.js';

describe('Day 20: Pulse Propagation - Part 1', () => {
    test('First example - simple broadcast chain', () => {
        const input = `broadcaster -> a, b, c
%a -> b
%b -> c
%c -> inv
&inv -> a`;
        expect(solution(input)).toBe(32000000);
    });

    test('Second example - conjunction and flip-flops', () => {
        const input = `broadcaster -> a
%a -> inv, con
&inv -> b
%b -> con
&con -> output`;
        expect(solution(input)).toBe(11687500);
    });
});