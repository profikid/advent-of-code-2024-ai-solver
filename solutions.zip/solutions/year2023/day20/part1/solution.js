class Module {
    constructor(name, type, destinations) {
        this.name = name;
        this.type = type;
        this.destinations = destinations;
        this.state = false; // for flip-flops
        this.memory = {}; // for conjunctions
    }
}

export default function solution(input) {
    const modules = new Map();
    let lowPulses = 0;
    let highPulses = 0;

    // Parse input and create modules
    input.split('\n').forEach(line => {
        if (!line.trim()) return;
        let [source, destinations] = line.split(' -> ');
        destinations = destinations.split(', ');
        
        let type = 'broadcast';
        let name = source;
        
        if (source !== 'broadcaster') {
            type = source[0];
            name = source.slice(1);
        }
        
        modules.set(name, new Module(name, type, destinations));
    });

    // Initialize conjunction modules' memory
    for (const [name, module] of modules) {
        for (const dest of module.destinations) {
            const destModule = modules.get(dest);
            if (destModule && destModule.type === '&') {
                destModule.memory[name] = 'low';
            }
        }
    }

    function pressButton() {
        const queue = [['button', 'broadcaster', 'low']];
        
        while (queue.length > 0) {
            const [source, target, pulse] = queue.shift();
            
            // Count pulses
            if (pulse === 'low') lowPulses++;
            else highPulses++;
            
            const module = modules.get(target);
            if (!module) continue;
            
            if (module.type === 'broadcast') {
                for (const dest of module.destinations) {
                    queue.push([target, dest, pulse]);
                }
            }
            else if (module.type === '%') {
                if (pulse === 'low') {
                    module.state = !module.state;
                    const newPulse = module.state ? 'high' : 'low';
                    for (const dest of module.destinations) {
                        queue.push([target, dest, newPulse]);
                    }
                }
            }
            else if (module.type === '&') {
                module.memory[source] = pulse;
                const allHigh = Object.values(module.memory).every(p => p === 'high');
                const newPulse = allHigh ? 'low' : 'high';
                for (const dest of module.destinations) {
                    queue.push([target, dest, newPulse]);
                }
            }
        }
    }

    // Press button 1000 times
    for (let i = 0; i < 1000; i++) {
        pressButton();
    }

    return lowPulses * highPulses;
}