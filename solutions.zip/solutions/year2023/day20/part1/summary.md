I have implemented the solution for Day 20 Part 1. Let me explain the approach:

1. First, I created a Module class that represents each module in the system with its properties:
   - name: module name
   - type: broadcast, % (flip-flop), or & (conjunction)
   - destinations: list of destination modules
   - state: for flip-flops (on/off)
   - memory: for conjunctions (remembering last pulse from each input)

2. The solution function:
   - Parses the input to create a map of all modules
   - Initializes conjunction modules by setting up their memory of input modules
   - Implements a pressButton function that simulates one button press
   - Uses a queue to process pulses in the correct order
   - Counts low and high pulses
   - Runs the simulation 1000 times
   - Returns the product of total low and high pulses

3. The pressButton function simulates the pulse propagation:
   - Uses a queue to ensure pulses are processed in the correct order
   - Handles each module type according to the rules:
     - Broadcast: sends same pulse to all destinations
     - Flip-flop (%): only responds to low pulses, toggles state
     - Conjunction (&): remembers inputs, sends low only if all inputs are high

4. The test cases verify both example scenarios from the puzzle description:
   - First example with the simple broadcast chain (expected: 32000000)
   - Second example with conjunction and flip-flops (expected: 11687500)

The solution has been tested and works correctly for both test cases. It properly handles the pulse propagation rules, module state changes, and pulse counting. The code is also careful to handle edge cases such as undefined modules and empty lines in the input.